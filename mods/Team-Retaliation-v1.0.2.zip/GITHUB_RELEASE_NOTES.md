## Team Retaliation v1.0.2

**Star Wars: Zero Company** companion mod for **Player Buff and Passive Retaliation**.

Your heroes **fire back together** whenever an enemy targets any member of your squad — every hero who still has a return-fire charge shoots back at the attacker.

- Friendly fire is blocked: your heroes never return fire at each other.
- Enemies keep their original behavior and do not gain team-wide return fire.
- Damage, AI, and saves are unchanged.

### What's new in 1.0.2

**A safety release. Nothing about how your squad fights back has changed.**

While investigating a player's mid-combat crash, we found the install on that machine was not the combination this mod ships: an experimental data file that had **never been tested in game** was present alongside the guard, and it made the game build roughly **twice as many return-fire attempts for every enemy action**. The mod did not fire more shots — the guard discarded half of them — but the game still had to set every one of them up, and the combat director spent the rest of that turn repeatedly timing out and force-skipping.

- **That extra data file is no longer distributed.** This archive contains only the long-tested data change, byte-for-byte identical to 1.0.0 and 1.0.1.
- **An experimental routing rule is now off by default** (`class_routing=0`, new setting). It only ever belonged with the withdrawn data file, and it could also suppress a Jedi's Force Push return fire.
- **The self-check no longer cries wolf.** 1.0.1 printed `hooks_fail=8` and `GUARD SILENT` even when everything was fine; both were reporting bugs on our side.
  - Health is now reported as `hooks_missing=N` — `hooks_missing=0` means healthy.
  - `GUARD SILENT` only appears after a real fight produced no return fire; before that the state is reported as `idle`.
  - `GUARD INACTIVE` (the warning that actually matters) still appears immediately.
  - A first-pass hook miss now logs `hook deferred (retried automatically)` instead of `hook unavailable`, because that is what it is.
- The guard schedules fewer timers per map load, after this UE4SS build logged `Lua::Registry::get_function_ref Ref was not function` for stale timer references.

If you saw `hooks_fail=8` or `GUARD SILENT` on a 1.0.1 install that otherwise worked, that was a false alarm on our side. Sorry for the noise.

### Am I affected if 1.0.1 worked for me?

No. This release changes nothing you can see except quieter, more accurate logs and no routing rule. Updating is still recommended, because it also removes the ability for that untested data file to end up in your install.

### Install (two parts)
1. Install the player buff mod (gives every hero 6 return-fire charges each team turn).
2. Copy `pak\006_retaliation_anyunit_P.{pak,ucas,utoc}` into `SWZeroCompany\Content\Paks\~mods\`.
3. Copy the `RetaliationGuard` folder into `SWZeroCompany\Binaries\Win64\ue4ss\Mods\`.
4. Add `RetaliationGuard : 1` to `ue4ss\Mods\mods.txt` above `Keybinds : 1`.

Both parts are required: the data file makes your squad fire back, the guard keeps that off your own side.

Chinese readme: `README.md` in the archive.

**Nexus (player buff mod):** https://www.nexusmods.com/starwarszerocompany/mods/86
