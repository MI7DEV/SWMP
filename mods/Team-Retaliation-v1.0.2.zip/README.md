# 小队反击 (Team Retaliation)

**星球大战：零号连队** MOD · 版本 **1.0.2**

本 MOD 是 **[原力爆发 · 玩家增益与被被动反击](https://github.com/weibinglove2799-svg/SWZC-ForceBurst-PlayerBuff)**（下称"玩家增益 MOD"）的联动子 MOD。它让你的英雄在敌人瞄准**小队中任意一人**时**集体还击**，而不只是被瞄准的那名士兵还击。

本 MOD 由两部分组成：一个放宽反击触发条件的数据包（`.pak`），以及一个阻止我方英雄互相开火的守卫（UE4SS 脚本）。敌人**不会**获得这种团队行为。

---

## 功能

原版游戏里，敌人瞄准我方某名英雄时，只有那名英雄会还击——而且必须有剩余反击层数。

装上**小队反击**后，敌人攻击**我方任意一名英雄**，**所有还有反击层数的英雄**都会朝那名敌人开火。一个小队被打，全队还手。

### 守卫（保证安全）

- 我方英雄**绝不会互相开火**。你主动攻击敌人时，队友不会调转枪口打你。
- 敌人**不会**得到团队反击行为，它们的反击保持原版。
- 本 MOD 不额外增加层数，只决定*已有的层数何时可以开火*。

### 不变的部分

伤害数值、敌人 AI 决策、存档、反击层数的获取方式全部不变。本 MOD 只影响**何时**扣扳机。

---

## 为什么需要"玩家增益 MOD"

反击需要**层数**。原版给得很慢，而且只给受过相应训练的特定英雄。

**[原力爆发 · 玩家增益与被动反击](https://github.com/weibinglove2799-svg/SWZC-ForceBurst-PlayerBuff)** 会给**每名英雄在你方每回合开始时发 6 层反击**。稳定的层数供给才能让全队反击稳定出现。没有它，小队反击依然生效，但只能靠队员自己攒层数，触发频率会低很多——也就是说，只有在培养出懂反击的队员之后，你才能体验到完整效果。

请先装玩家增益 MOD，再在其上叠加小队反击。

---

## 安装

本 MOD 分两部分：游戏数据文件（`.pak`）和 UE4SS 文件夹。

1. 先安装 **[玩家增益 MOD](https://github.com/weibinglove2799-svg/SWZC-ForceBurst-PlayerBuff)** 及其对应游戏版本的 **UE4SS**。
2. 完全关闭游戏。
3. 把 `pak\` 里的三个文件复制到：

   `SWZeroCompany\Content\Paks\~mods\`
   - `006_retaliation_anyunit_P.pak`
   - `006_retaliation_anyunit_P.ucas`
   - `006_retaliation_anyunit_P.utoc`

4. 把 **`RetaliationGuard`** 文件夹复制到：

   `SWZeroCompany\Binaries\Win64\ue4ss\Mods\`

5. 打开 `ue4ss\Mods\mods.txt`，在 `Keybinds : 1` **上方**加一行：

   `RetaliationGuard : 1`

6. 启动游戏。`UE4SS.log` 里应能看到 `Starting Lua mod 'RetaliationGuard'` 和 `LOAD version=1.6`。

> 两部分都要装。`.pak` 负责"全队还击"，守卫负责"不误伤自己人"。只装其中一个得到的是半成品。

---

## 卸载

1. 删掉 `Content\Paks\~mods\` 下的三个 `006_retaliation_anyunit_P.*`。
2. 删掉 `ue4ss\Mods\RetaliationGuard` 文件夹。
3. 从 `mods.txt` 移除 `RetaliationGuard : 1` 那一行。

---

## 1.0.2 更新内容

**1.0.2 是安全更新，小队还击的玩法没有任何变化。**

在帮一位遇到"战斗中崩溃"的玩家排查时发现：他那台机器上装的组合并不是本 MOD 实际发布的组合——一个**从未在游戏中验证过**的实验性数据包和守卫一起留在装机里，它会让游戏在敌人每次行动时**构建大约两倍的还击尝试**。游戏并没有因此多打枪（守卫会掐掉一半），但**这些尝试本身都要被引擎搭起来**，结果战斗导演在那一回合里反复超时、反复强制跳过演出。

1.0.2 的处理：

- **那个额外数据包不再提供。** 本压缩包里只有长期验证过的那个数据改动（与 1.0.0 / 1.0.1 **逐字节相同**），翻倍负载的成因被移除。
- **实验性通道路由默认关闭**（新增设置 `class_routing=0`）。它本来只为配合上面那个已移除的数据包，而且还会误伤绝地英雄的原力推反击。
- **自检不再假警报。** 1.0.1 会在一切正常时也打印 `hooks_fail=8` 和 `GUARD SILENT`——那是我们报告逻辑的 bug，不是你的安装有问题。
  - 健康值改为 `hooks_missing=N`，正常即 `hooks_missing=0`。
  - `GUARD SILENT` 只在打完一场仗、却始终没有反击事件到达守卫时才出现；在那之前只报 `idle`。
  - 真正要紧的 `GUARD INACTIVE` 依旧立刻报警。
  - 首次挂载失败改叫 `hook deferred (retried automatically)`（资产还没加载进来，属正常），只有最终失败才叫 `hook unavailable`。

如果你在能正常工作的 1.0.1 上见过 `hooks_fail=8` 或 `GUARD SILENT`，那是我们这边的假警报，很抱歉造成困扰。

### 那 1.0.1 是不是坏了？

没有。如果 1.0.1 在你机器上工作正常，1.0.2 除了日志更安静更准确、以及关掉一条路由规则之外，你感知不到区别。仍然建议更新，因为它也移除了"那个未验证数据包混进装机"的可能性。

### 如果英雄之间还是会互相开火

打开 `ue4ss\UE4SS.log`，找最近的 `[RetaliationGuard` 行：

- **`GUARD ACTIVE`** —— 一切正常。
- **`GUARD INACTIVE`** —— 防护在你这个游戏版本上**没有运行**。请把整行贴出来，一行就能定位问题。
- **`GUARD SILENT`** —— 守卫加载了，但一场仗下来没有任何反击事件到达它，防护很可能也没在起作用。同样值得反馈。

守卫还会为每个找到的反击技能写一行 `discover class=...`，这正是适配新游戏版本最需要的信息。

### 可选设置（`RetaliationGuard\config.ini`）

| 设置 | 默认 | 作用 |
| --- | --- | --- |
| `enabled` | `1` | 完全关闭守卫。不推荐——友伤会回来。 |
| `verbose` | `0` | 记录每一次判定。日志很吵，只用于排查。 |
| `dry_run` | `0` | 只观察不拦截。诊断用。 |
| `auto_discover` | `1` | 让守卫按名字在运行时查找反击技能，游戏补丁改名也不会静默失效。 |
| `strict_undecidable` | `0` | 高级。单位身份无法识别时就拦截。也可能拦掉正常反击——除非被要求，保持 `0`。 |
| `class_routing` | `0` | 高级，默认关。把绝地送到原力推通道、枪兵送到步枪通道。其职业判定依赖名字、不可靠，保持 `0`。 |

---

## 排查

在 `RetaliationGuard\config.ini` 里把 `verbose=1`，游戏里 `ue4ss\UE4SS.log` 会记录每次判定（以 `[RetaliationGuard` 开头）。排查完记得改回 `0`。

**GitHub：** https://github.com/weibinglove2799-svg/SWZC-Team-Retaliation
