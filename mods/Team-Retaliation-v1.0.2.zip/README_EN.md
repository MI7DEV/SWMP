# Team Retaliation

**Star Wars: Zero Company** mod · Version **1.0.2**

A companion mod for **[Player Buff and Passive Retaliation](https://github.com/weibinglove2799-svg/SWZC-ForceBurst-PlayerBuff)** (the "player buff" mod). It makes your heroes **fire back together** whenever an enemy lines up an attack on **any** member of your squad — not just the soldier being aimed at.

It has two parts: a small data change that widens the return-fire trigger, and a guard that stops friendly fire between your own heroes. Enemies are not given the same teamwork behavior.

---

## What this mod does

In the base game, when an enemy targets one of your heroes, only that hero returns fire — and only if they have a return-fire charge ready.

With **Team Retaliation** installed, when an enemy attacks *any one of your heroes*, **every hero who still has a return-fire charge** will shoot back at that enemy. Your squad fights as a unit: one ally comes under fire, the whole team answers.

### The guard (keeps it safe)

- Your heroes **never fire back at each other**. If you attack an enemy, your teammates will not turn and shoot you.
- Enemies **do not** gain this teamwork behavior. Their return fire stays exactly as the game made it.
- No extra charges are added by this mod. It only decides *when existing charges may fire*.

### What stays unchanged

Damage numbers, enemy AI decisions, your saves, and how return-fire charges are earned are all untouched. This mod only affects **when** your team pulls the trigger.

---

## Why it needs the "player buff" mod

Return fire needs **charges**. The base game gives them out slowly, and only to heroes with the right training.

The **[Player Buff and Passive Retaliation](https://github.com/weibinglove2799-svg/SWZC-ForceBurst-PlayerBuff)** mod grants **every hero 6 return-fire charges at the start of each of your turns**. That steady supply is what makes squad-wide return fire happen reliably. Without it, Team Retaliation still works, but only as often as your heroes happen to hold charges on their own — so you will only see its full effect once you have built and trained a squad of heroes who know how to return fire.

Install the player buff mod first, then add Team Retaliation on top.

---

## Install

This mod has two parts: game data files (`.pak`) and a UE4SS folder.

1. Install the **[player buff mod](https://github.com/weibinglove2799-svg/SWZC-ForceBurst-PlayerBuff)** and its required game-specific **UE4SS** build.
2. Close the game completely.
3. Copy the three files from `pak\` into your mods folder:

   `SWZeroCompany\Content\Paks\~mods\`
   - `006_retaliation_anyunit_P.pak`
   - `006_retaliation_anyunit_P.ucas`
   - `006_retaliation_anyunit_P.utoc`

4. Copy the **`RetaliationGuard`** folder into:

   `SWZeroCompany\Binaries\Win64\ue4ss\Mods\`

5. Open `ue4ss\Mods\mods.txt` and add this line **above** `Keybinds : 1`:

   `RetaliationGuard : 1`

6. Launch the game. `UE4SS.log` should show `Starting Lua mod 'RetaliationGuard'` and `LOAD version=1.6`.

> Both parts matter. The `.pak` is what makes the whole squad fire back; the guard is what keeps that from hitting your own side. Installing only one of them gives you the unfinished behavior.

---

## Uninstall

1. Delete the three `006_retaliation_anyunit_P.*` files from `Content\Paks\~mods\`.
2. Delete the `ue4ss\Mods\RetaliationGuard` folder.
3. Remove the `RetaliationGuard : 1` line from `mods.txt`.

---

## What's new in 1.0.2

**1.0.2 is a safety release. Nothing about how your squad fights back has changed.**

While supporting a player whose session ended in a crash, we found the combination that had been left installed on that machine was not the combination this mod actually ships: an experimental data file that had **never been tested in game** was present alongside the guard, and it caused the game to build roughly **twice as many return-fire attempts for every enemy action**. The mod was not producing more shooting — the guard was throwing half of them away — but the game still had to set all of them up, and the combat director spent the rest of that turn repeatedly timing out and force-skipping.

What 1.0.2 does about it:

- **The extra data file is gone.** This archive contains only the long-tested data change (byte-for-byte the same as 1.0.0 and 1.0.1), so the doubled work cannot happen.
- **An experimental routing rule is now switched off** (`class_routing=0`, new setting). It was only ever meant to go with that removed data file, and it could also quietly suppress a Jedi's Force Push return fire.
- **The self-check no longer cries wolf.** 1.0.1 printed `hooks_fail=8` and `GUARD SILENT` even when everything was fine. Both were our reporting bugs, not your install.
  - Health is now reported as `hooks_missing=N`; healthy is `hooks_missing=0`.
  - `GUARD SILENT` only appears after a real fight with no return fire reaching the guard. Before that it reports `idle`.
  - `GUARD INACTIVE` — the one warning that matters — still appears immediately.
  - A first-pass hook miss now logs `hook deferred (retried automatically)` instead of `hook unavailable`, because that is what it is.

If you saw `hooks_fail=8` or a `GUARD SILENT` on a working 1.0.1 install, that was a false alarm on our side. Sorry for the noise.

### Is 1.0.1 broken for me?

No. If 1.0.1 was working for you, 1.0.2 changes nothing you can see except quieter, more accurate logs and no routing rule. Updating is still recommended, because it also removes the ability for that untested data file to end up in your install.

### If your heroes ever shoot each other

Open `ue4ss\UE4SS.log` and look for the most recent `[RetaliationGuard` lines:

- **`GUARD ACTIVE`** — everything is working.
- **`GUARD INACTIVE`** — the protection is **not** running on your game version. Please post that whole line when you report the issue; it names the problem in one shot.
- **`GUARD SILENT`** — the guard loaded but no return fire has reached it during a fight, so the protection is probably not doing anything either. Also worth reporting.

The guard also writes a `discover class=...` line for every return-fire skill it found, which is exactly what we need to support a new game version.

### Optional settings (`RetaliationGuard\config.ini`)

| Setting | Default | What it does |
| --- | --- | --- |
| `enabled` | `1` | Turn the guard off entirely. Not recommended — friendly fire comes back. |
| `verbose` | `0` | Log every decision. Noisy; only for troubleshooting. |
| `dry_run` | `0` | Watch-only mode: never blocks anything. Diagnostics. |
| `auto_discover` | `1` | Let the guard find return-fire skills by name, so a game patch that renames them does not disable it. |
| `strict_undecidable` | `0` | Advanced. Block when a unit cannot be identified. Can also block legitimate return fire — leave at `0` unless asked. |
| `class_routing` | `0` | Advanced, off. Sends Jedi to Force Push and gunners to rifle fire. Its unit check is name-based and unreliable; leave at `0`. |

---

## Troubleshooting

Set `verbose=1` in `RetaliationGuard\config.ini` to log every decision, then check `ue4ss\UE4SS.log` for lines starting with `[RetaliationGuard`. Set it back to `0` afterwards.

**GitHub:** https://github.com/weibinglove2799-svg/SWZC-Team-Retaliation
