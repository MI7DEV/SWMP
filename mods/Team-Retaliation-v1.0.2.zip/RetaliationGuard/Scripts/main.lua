-- RetaliationGuard (v1.6)
--
-- v1.6 (2026-09-16): CRASH FOLLOW-UP.  The first live run of v1.5 happened the
-- same day and the session ended in a crash during the enemy turn (map
-- MM_03_010_Bespin, log 19:59:08 -> 20:00:46).  Two things were wrong with the
-- combination that was installed, and both are fixed here:
--
--   1. The installed DATA pak was the never-validated 006 v2, which widened the
--      ForcePush channel in addition to the rifle channel.  That doubles the
--      number of retaliation candidates every enemy action spawns (each hero
--      gets a rifle candidate AND a force-push candidate) and the guard then had
--      to short-circuit half of them.  The log shows exactly that: the guard
--      returned "non-jedi-no-push" for gunner heroes such as
--      Char_Hero_HAWKS_Control_C, while SwiftCombat armed a COUNTER window for
--      every instance.  The shipped, in-game-validated pak (006 v1, rifle
--      channel only) has been restored, so channel routing is not needed at all.
--   2. CLASS ROUTING IS NOW OFF BY DEFAULT (config class_routing=0).  It only
--      ever made sense together with 006 v2.  It was also demonstrably wrong:
--      Char_Anakin_C carries no "char_hero_"/"_jedi_" token, so is_jedi_actor()
--      classified him as a non-Jedi and suppressed his real Force Push
--      retaliation.  Re-enabling it needs classification that is not name-based.
--
-- Also fixed in v1.6 (reporting correctness, no gameplay effect):
--   * STATUS reported "hooks_fail=8" on the v1.5 run even though all 8 hooks
--     were registered and healthy - that counter was a running tally of first
--     pass misses which retries had already recovered.  Health is now computed
--     against the live target list and prints hooks_missing instead.
--   * "GUARD SILENT" fired before any battle had started, which is a false
--     alarm.  It now waits out a grace period and reports "idle" until then.
--   * A first-pass hook miss now logs "hook deferred (retried automatically)"
--     rather than "hook unavailable"; only a real final failure says unavailable.
--   * Fewer scheduled timers per map load (health checks are folded into the
--     retry passes plus three late probes).  This UE4SS build logs
--     "Lua::Registry::get_function_ref Ref was not function" for stale timer
--     refs, so the callback count is deliberately small.
--
-- v1.5 (2026-09-16): GAME-UPDATE HARDENING.  Players reported that after the
-- game (and/or UE4SS) was patched, heroes started shooting the teammate who
-- was firing - i.e. the friendly-fire filter silently stopped working.  Root
-- cause of that failure mode (NOT a logic regression):
--   * v1.3/1.4 hooked FOUR hard-coded UFunction paths per channel.  If a patch
--     renames / re-parents / moves those retaliation assets, RegisterHook fails
--     ("hook unavailable ... no UFunction with the specified name was found")
--     and the guard then does exactly NOTHING: every candidate is allowed and
--     friendly fire comes straight back.
--   * The decision code reads FGameplayEventData / ActorInfo fields.  If a patch
--     changes those struct layouts, owner/inst resolution returns nil and v1.4
--     deliberately falls back to the vanilla verdict (fail-open) -> same result.
--   Either way the failure was SILENT, which is why it looked like a logic bug.
--
-- v1.5 fixes that class of failure instead of the one patch:
--   1. RUNTIME DISCOVERY.  Hook targets are no longer only the known paths;
--      every loaded class whose short name starts with ga_retaliat / uga_retaliat
--      (minus the layer-granting "generate" passives) is discovered via
--      FindAllOf and hooked with the SAME rules.  Channel is derived from the
--      class name: force/push -> "push", otherwise "shot".  So a rename or a new
--      retaliation GA still gets covered, and the discovered names are logged.
--   2. LOUD STATUS.  Aggregate self-check after the hook retries and periodically
--      afterwards.  "GUARD INACTIVE" = zero hooks attached; "GUARD SILENT" =
--      hooks attached but the engine never consulted them.  Both used to be
--      invisible.  One log line now identifies a broken build immediately.
--   3. Config switches: auto_discover (default on) and strict_undecidable
--      (default off, advanced: block instead of fail-open when actors cannot be
--      resolved - can cost legitimate retaliation, so it is opt-in only).
--
-- Behavior on the frozen/unpatched build is unchanged: discovery finds the same
-- two assets the hard-coded paths already point at, so they dedupe and the
-- validated v1.3/v1.4 rules apply verbatim.
--
-- v1.4 (2026-09-03): class-channel routing. 006 now widens BOTH retaliation
-- opening-fire GAs to AnyUnitTargeted (GA_RetaliationShot_Heavy_NEW for gunners
-- + GA_RetaliationForcePush for Jedi), so:
--   * Jedi (e.g. Char_Hero_TelRea_Jedi) keep their group retaliation but on the
--     force-push channel: their Heavy_NEW (rifle) candidates are always blocked.
--   * A non-Jedi hero's ForcePush candidate is always blocked (only Jedi push).
--   * Same-team provokers are still blocked on both channels (no friendly fire /
--     no internal ping-pong). Enemies keep only their own vanilla single target.
--   * pending_block is scoped per (owner, channel) so a Jedi blocked on the
--     rifle channel can never suppress their own force-push in the same event.
--
-- WHAT THE v1.2 LOG PROVED (2026-09-02 23:48-23:53, map SK_Vandor_020):
--   * owner/inst/victim ARE fully resolvable at K2_ShouldAbilityRespondToEvent
--     (owner from ActorInfo.AvatarActor, inst/victim from Payload). The Gate
--     correctly blocked every friendly-chain candidate (hero-same-team), yet the
--     engine STILL created the instances: 3 x GATE-LEAK (Cly/Jae/HAWKS) each
--     followed ~50ms later by SwiftCombat "COUNTER presentation".  Friendly
--     damage + animation therefore came back in v1.2.
--   * Cause: v1.2 relied on RETURNING false from a single POST hook on
--     K2_ShouldAbilityRespondToEvent.  In this engine a Lua return value from a
--     BP event POST hook does NOT propagate to the caller that decides
--     activation.  SwiftCombat never overrides BP return values; it writes OUT
--     PARAMS (can_skip:set/should_play:set) and registers PRE+POST hook pairs.
--   * Enemies never run GA_RetaliationShot_Heavy_NEW (0 occurrences in whole
--     log); only the four heroes do.  So the widened trigger only exists on the
--     hero side; there is no enemy "group cover" coming through this GA.
--
-- v1.3 STRATEGY (all SwiftCombat-verified mechanisms, no return overrides):
--   1. K2_ShouldAbilityRespondToEvent: PRE + POST pair.  In PRE we can return
--      false to SHORT-CIRCUIT the BP (UE4SS skips the original body and hands
--      false back to the caller who consults the respond check before
--      instancing).  POST stays as a trace + safety net.
--   2. K2_CanActivateAbility: second pre-activation gate on the same asset,
--      also PRE+POST with false short-circuit for blocked decisions.
--   3. CanDoReaction(bool& CanDoActivation): engine/higher-BP consults this with
--      an OUT bool before letting a reaction fire.  We set the out param to
--      false for blocked owners via the POST hook (out-param write is the one
--      mechanism this engine demonstrably honors).  CanDoReaction carries no
--      owner argument, so we resolve owner from the context instance if it is
--      bound, else we fall back to a short-lived "pending block" set filled by
--      the K2_ShouldAbilityRespondToEvent Gate (owner resolved there).
--   4. Activate-leak detector stays (read-only) to prove whether the gates now
--      bite: if v1.3 works, "would-block" instances never reach activation.
--
-- Rules (owner = holder, inst = provoker, victim = targeted unit, per channel):
--   * owner & inst same side                 -> block (no hero internal chain;
--                                                also no self-refire)
--   * hero holder + enemy inst, routing ON,  -> Jedi block (jedi-no-gun) else
--     channel=shot                              allow
--   * hero holder + enemy inst, routing ON,  -> non-Jedi block else allow (Jedi)
--     channel=push
--   * hero holder + enemy inst, routing OFF  -> allow on both channels
--   * enemy holder + hero inst               -> only its own target allowed
--   * unresolvable (nil/nameless actor)      -> nil = leave vanilla verdict
--                                               (or block if strict_undecidable)

local MOD_NAME = "RetaliationGuard"
local MOD_VERSION = "1.6"
local BUILD_ID = "1.6-crash-safe"

local registered = {}
local failed = {}
local log_counts = {}
local config = {
    enabled = true,
    dry_run = false,
    verbose = false,
    auto_discover = true,
    strict_undecidable = false,
    class_routing = false,
}

-- Owner full names we intend to block, filled by the Gate, consumed by
-- CanDoReaction / leak checks that lack an ActorInfo argument. Cleared when an
-- activation of that owner is seen or after a short TTL.
local pending_block = {}
local PENDING_TTL = 1.5

-- Aggregate health counters.  "hooks_ok/missing" are computed against the
-- CURRENT target list at report time (a first-attempt failure that a later
-- retry recovered must not be reported as a failure - the v1.5 first run
-- printed "hooks_fail=8" while all 8 hooks were in fact healthy).
local stats = {
    gate_calls = 0,
    blocks = 0,
    allows = 0,
    leaks = 0,
}

-- Target paths attempted by the most recent register pass.
local current_targets = {}

local function log(message)
    print(string.format("[%s %.3f] %s\n", MOD_NAME, os.clock(), tostring(message)))
end

local function rate_logged(key)
    log_counts[key] = (log_counts[key] or 0) + 1
    return log_counts[key] <= 80
end

local function trim(value)
    return (value or ""):gsub("^%s+", ""):gsub("%s+$", "")
end

local function parse_bool(value)
    local lower = string.lower(trim(value))
    if lower == "true" or lower == "1" or lower == "on" or lower == "yes" then
        return true
    end
    if lower == "false" or lower == "0" or lower == "off" or lower == "no" then
        return false
    end
    return nil
end

local function config_path()
    local ok, directories = pcall(IterateGameDirectories)
    local win64 = ok and directories and directories.Game
        and directories.Game.Binaries and directories.Game.Binaries.Win64
    if not win64 then
        return nil
    end
    return win64.__absolute_path .. "\\ue4ss\\Mods\\" .. MOD_NAME .. "\\config.ini"
end

local function load_config()
    local path = config_path()
    if not path then
        log("config path unavailable; defaults")
        return
    end
    local file = io.open(path, "r")
    if not file then
        log("config missing; defaults")
        return
    end
    for raw_line in file:lines() do
        local line = trim(raw_line:gsub("[;#].*$", ""))
        if line ~= "" and line:sub(1, 1) ~= "[" then
            local key, value = line:match("^([^=]+)=(.*)$")
            if key and value then
                key = trim(key):lower()
                if key == "enabled" then
                    local p = parse_bool(value)
                    if p ~= nil then config.enabled = p end
                elseif key == "dry_run" then
                    local p = parse_bool(value)
                    if p ~= nil then config.dry_run = p end
                elseif key == "verbose" then
                    local p = parse_bool(value)
                    if p ~= nil then config.verbose = p end
                elseif key == "auto_discover" then
                    local p = parse_bool(value)
                    if p ~= nil then config.auto_discover = p end
                elseif key == "strict_undecidable" then
                    local p = parse_bool(value)
                    if p ~= nil then config.strict_undecidable = p end
                elseif key == "class_routing" then
                    local p = parse_bool(value)
                    if p ~= nil then config.class_routing = p end
                end
            end
        end
    end
    file:close()
    log("config enabled=" .. tostring(config.enabled)
        .. " dry_run=" .. tostring(config.dry_run)
        .. " verbose=" .. tostring(config.verbose)
        .. " auto_discover=" .. tostring(config.auto_discover)
        .. " strict_undecidable=" .. tostring(config.strict_undecidable)
        .. " class_routing=" .. tostring(config.class_routing))
end

local function unwrap(value)
    if not value then return nil end
    local ok, got = pcall(function() return value:get() end)
    if ok and got then return got end
    return value
end

-- Dereference a possibly-wrapped actor (RemoteUnrealParam / weak-ptr wrapper /
-- plain AActor) down to an object that answers GetFullName with a real name.
local function as_actor(value)
    local v = value
    for _ = 1, 4 do
        if not v then
            return nil
        end
        local ok, name = pcall(function()
            return tostring(v:GetFullName())
        end)
        if ok and type(name) == "string" and name ~= "" then
            return v
        end
        local ok2, got = pcall(function() return v:get() end)
        if not ok2 or got == nil or got == v then
            return nil
        end
        v = got
    end
    return nil
end

local function full_name_of(value)
    local object = as_actor(value)
    if not object then return "" end
    local ok, name = pcall(function() return tostring(object:GetFullName()) end)
    if ok and name then return name end
    return ""
end

local function is_enemy_actor(value)
    local name = string.lower(full_name_of(value))
    return name ~= "" and name:find("char_enemy_", 1, true) ~= nil
end

-- Jedi / force-channel holders among the heroes: actor blueprint names carry
-- the class token (e.g. Char_Hero_TelRea_Jedi_C). Keep the check loose enough
-- to catch future Jedi-style hero classes without touching enemies (which also
-- never match char_hero_).
local function is_jedi_actor(value)
    local name = string.lower(full_name_of(value))
    return name ~= "" and name:find("char_hero_", 1, true) ~= nil
        and name:find("_jedi_", 1, true) ~= nil
end

local function name_of(value)
    local name = full_name_of(value)
    if name == "" then return "nil" end
    return name:match("([^%.]+)") or name
end

local function actor_key(value)
    local name = full_name_of(value)
    if name == "" then return nil end
    return name
end

-- Try to read an actor field that may live on the raw param or on the struct
-- produced by :get(). Used for ActorInfo.AvatarActor/OwnerActor and
-- Payload.Instigator/Target.
local function try_actor(root, field_name)
    if not root then return nil end
    local roots = { root }
    local ok, got = pcall(function() return root:get() end)
    if ok and got and got ~= root then
        roots[#roots + 1] = got
    end
    for _, r in ipairs(roots) do
        local okf, val = pcall(function() return r[field_name] end)
        if okf and val ~= nil then
            local actor = as_actor(val)
            if actor then
                return actor
            end
        end
    end
    return nil
end

-- Owner of the ability = avatar/owner unit from the ActorInfo argument.
local function owner_from_actor_info(actor_info_param)
    local owner = try_actor(actor_info_param, "AvatarActor")
    if not owner then
        owner = try_actor(actor_info_param, "OwnerActor")
    end
    return owner
end

-- Instigator / target of the provoking action from the Payload argument.
local function read_payload(payload_param)
    local inst = try_actor(payload_param, "Instigator")
    local victim = try_actor(payload_param, "Target")
    return inst, victim
end

-- Decide action for one candidate reaction on one channel.
-- channel: "shot" (rifle retaliation) or "push" (force-push retaliation).
-- Returns action, reason: "block" | "allow" | nil (=leave vanilla decision).
local function decide(channel, owner_actor, inst_actor, victim_actor)
    if not config.enabled then
        return nil, "disabled"
    end
    if not owner_actor or not inst_actor then
        if config.strict_undecidable then
            return "block", "undecidable-strict"
        end
        return nil, "undecidable"
    end

    local owner_enemy = is_enemy_actor(owner_actor)
    local inst_enemy = is_enemy_actor(inst_actor)

    if owner_enemy == inst_enemy then
        -- Same side provoked the event: no friendly fire, no internal chain.
        return "block", (owner_enemy and "enemy-same-team" or "hero-same-team")
    end

    if not owner_enemy then
        -- Hero holder reacting to an enemy provoker.
        local owner_jedi = is_jedi_actor(owner_actor)
        if not config.class_routing then
            -- Routing OFF (default). Both channels stay open for heroes; the
            -- same-team rule above still blocks friendly fire.
            --
            -- Why off by default: routing existed to steer a hero's widened
            -- ForcePush candidate onto a Jedi. With the 006 v2 pak withdrawn
            -- (see below) the ForcePush channel is NOT widened any more, so
            -- routing would only ever block legitimate candidates. It was also
            -- observed blocking `Char_Anakin_C`: his actor name carries no
            -- "char_hero_"/"_jedi_" token, so he was classified as a non-Jedi
            -- and his real Force Push retaliation was suppressed. Enabling
            -- routing again requires a classification that is not name-based.
            return "allow",
                (channel == "push" and "hero-push" or "hero-cover-or-self")
        end
        if channel == "push" then
            -- Only Jedi run the force-push channel; a gunner-held ForcePush
            -- (widened by the 006 v2 pak) must never activate.
            if not owner_jedi then
                return "block", "non-jedi-no-push"
            end
            return "allow", "jedi-cover-or-self"
        end
        -- channel == "shot": Jedi never aim the rifle (they push instead);
        -- gunners keep group cover fire.
        if owner_jedi then
            return "block", "jedi-no-gun"
        end
        return "allow", "hero-cover-or-self"
    end

    -- Enemy holder provoked by a hero: only its own targeting is allowed.
    local owner_name = full_name_of(owner_actor)
    if not owner_name or owner_name == "" then
        return nil, "undecidable"
    end
    if victim_actor and full_name_of(victim_actor) == owner_name then
        return "allow", "enemy-self-single"
    end
    return "block", (victim_actor and "enemy-cover" or "enemy-cover-novictim")
end

-- Log a decision (blocks always; allows only in verbose).
local function trace(stage, action, reason, owner_actor, inst_actor, victim_actor)
    if action == "block" or config.verbose then
        local key = stage .. ":" .. tostring(action or "nil")
        if rate_logged(key) then
            log("DECISION stage=" .. tostring(stage)
                .. " action=" .. tostring(action or "nil")
                .. " reason=" .. tostring(reason or "nil")
                .. " owner=" .. name_of(owner_actor)
                .. " inst=" .. name_of(inst_actor)
                .. " victim=" .. name_of(victim_actor))
        end
    end
end

local function remember_blocked(owner_actor, channel)
    local key = actor_key(owner_actor)
    if key then
        pending_block[key .. "::" .. channel] = os.clock()
    end
end

local function is_pending_block(owner_actor, channel)
    local key = actor_key(owner_actor)
    if not key then return false end
    local at = pending_block[key .. "::" .. channel]
    if not at then return false end
    if os.clock() - at > PENDING_TTL then
        pending_block[key .. "::" .. channel] = nil
        return false
    end
    return true
end

local function clear_pending_block(owner_actor, channel)
    local key = actor_key(owner_actor)
    if key then pending_block[key .. "::" .. channel] = nil end
end

-- ---------------------------------------------------------------------------
-- Hook targets (v1.5): known paths PLUS runtime discovery.
-- ---------------------------------------------------------------------------

-- Class paths that v1.3/1.4 proved correct on the unpatched build.
local KNOWN_CLASSES = {
    "/Game/Game/GameData/Abilities/Counters/Retaliate/"
        .. "GA_RetaliationShot_Heavy_NEW.GA_RetaliationShot_Heavy_NEW_C",
    "/Game/Game/GameData/Abilities/Counters/Retaliate/"
        .. "GA_RetaliationForcePush.GA_RetaliationForcePush_C",
}

local FUNC_NAMES = {
    "K2_ShouldAbilityRespondToEvent",
    "K2_CanActivateAbility",
    "CanDoReaction",
    "K2_ActivateAbilityFromEvent",
}

local function class_short_name(full)
    local lower = string.lower(full)
    return lower:match("([^%.]+)$") or lower
end

-- Map a retaliation class SHORT name to a channel, or nil when it is not an
-- opening-fire retaliation ability.  Deliberately name-based (not path-based)
-- so a patch that moves or re-parents the asset is still covered.
-- Split out from channel_for_class so the class scan can pre-filter on the
-- cheap GetName() before paying for a full path lookup.
local function channel_for_short_name(short)
    short = string.lower(short)
    if not (short:find("^ga_retaliat") or short:find("^uga_retaliat")) then
        return nil
    end
    -- "generate retaliation" is the passive that hands out charges, not a shot.
    if short:find("generate", 1, true) then
        return nil
    end
    if short:find("push", 1, true) or short:find("force", 1, true) then
        return "push"
    end
    return "shot"
end

local function channel_for_class(full)
    return channel_for_short_name(class_short_name(full))
end

local discovery_scans = 0
local DISCOVERY_MAX_SCANS = 6
local DISCOVERY_SCAN_BUDGET = 60000
local discovery_seen = {}

-- Cheap short name for a class object. GetName() is far cheaper than
-- GetFullName(), so the scan filters on it first.
local function class_object_short_name(object)
    local ok, name = pcall(function() return object:GetName() end)
    if ok and type(name) == "string" and name ~= "" then
        return name
    end
    local ok2, full = pcall(function() return object:GetFullName() end)
    if ok2 and type(full) == "string" and full ~= "" then
        return class_short_name(full)
    end
    return nil
end

-- Enumerate loaded classes and pick out retaliation opening-fire abilities.
-- Returns class_path -> channel.  Safe on old UE4SS: any API failure degrades
-- to "no extra targets" and the known paths still apply.
local function discover_classes()
    local found = {}
    local inspected = 0
    for _, query in ipairs({ "BlueprintGeneratedClass", "Class" }) do
        local ok, list = pcall(FindAllOf, query)
        if ok and type(list) == "table" then
            for _, object in pairs(list) do
                inspected = inspected + 1
                if inspected > DISCOVERY_SCAN_BUDGET then
                    break
                end
                local short = class_object_short_name(object)
                if short then
                    local channel = channel_for_short_name(short)
                    if channel then
                        local okf, full = pcall(function()
                            return object:GetFullName()
                        end)
                        if okf and type(full) == "string" and full ~= ""
                            and not found[full] then
                            found[full] = channel
                        end
                    end
                end
            end
        end
    end
    return found
end

local function build_targets()
    local targets = {}
    for _, class_path in ipairs(KNOWN_CLASSES) do
        targets[class_path] = channel_for_class(class_path) or "shot"
    end
    if config.auto_discover and discovery_scans < DISCOVERY_MAX_SCANS then
        discovery_scans = discovery_scans + 1
        local discovered = discover_classes()
        for class_path, channel in pairs(discovered) do
            if not targets[class_path] then
                targets[class_path] = channel
                if not discovery_seen[class_path] then
                    discovery_seen[class_path] = true
                    log("discover class=" .. class_path .. " channel=" .. channel)
                end
            end
        end
    end
    return targets
end

-- ---------------------------------------------------------------------------
-- Gate callbacks
-- ---------------------------------------------------------------------------

local function short_circuit_block(action)
    -- UE4SS PRE hooks: returning a value for a function with a return value
    -- skips the original body and hands that value to the caller. Blocked ->
    -- return false. Everything else -> return nil (run vanilla BP + return
    -- whatever it decides).
    if action == "block" and not config.dry_run then
        return false
    end
    return nil
end

-- THE gate (PRE part): runs before the BP respond check. Returning false here
-- short-circuits: the engine's pre-instance consult sees "no, do not respond".
local function on_should_respond_pre(channel, context, actor_info_param,
    payload_param)
    if not config.enabled then
        return nil
    end
    stats.gate_calls = stats.gate_calls + 1
    local owner = owner_from_actor_info(actor_info_param)
    local inst, victim = read_payload(payload_param)
    local action, reason = decide(channel, owner, inst, victim)
    trace("GatePRE", action, reason, owner, inst, victim)
    if action == "block" then
        stats.blocks = stats.blocks + 1
        remember_blocked(owner, channel)
    elseif action == "allow" then
        stats.allows = stats.allows + 1
        if owner then
            -- A legitimate decision context for this owner arrived: clear any
            -- stale friendly-chain mark so it never eats a later valid
            -- activation.
            clear_pending_block(owner, channel)
        end
    end
    return short_circuit_block(action)
end

-- POST: only informational now (the caller already read the return).
local function on_should_respond_post(channel, context, actor_info_param,
    payload_param)
    if not config.enabled then
        return
    end
    if not config.verbose then
        return
    end
    local owner = owner_from_actor_info(actor_info_param)
    local inst, victim = read_payload(payload_param)
    local action, reason = decide(channel, owner, inst, victim)
    trace("GatePOST", action, reason, owner, inst, victim)
end

-- K2_CanActivateAbility: second pre-activation consult. Same short-circuit.
-- Signature: bool K2_CanActivateAbility(ActorInfo, Handle, RelevantTags&)
local function on_can_activate_pre(channel, context, actor_info_param)
    if not config.enabled then
        return nil
    end
    local owner = owner_from_actor_info(actor_info_param)
    if not owner then
        return nil
    end
    -- No payload here; we only have the owner. Block only owners that were
    -- flagged as pending-block by the respond gate within TTL. That is exactly
    -- the same friendly chain we want to stop, and we never invent new blocks.
    if is_pending_block(owner, channel) then
        local action = "block"
        local reason = "can-activate-pending"
        trace("CanAct", action, reason, owner, nil, nil)
        return short_circuit_block(action)
    end
    return nil
end

-- CanDoReaction(bool& CanDoActivation): higher code asks "may this reaction
-- fire?" and reads the OUT bool afterwards.  Writes to out params are the one
-- thing this engine demonstrably honors (SwiftCombat can_skip).  Owner is not
-- an argument, so we resolve from the context instance if bound, else from the
-- pending-block set.
local function on_can_do_reaction(channel, context, out_param)
    if not config.enabled then
        return
    end
    local ability = as_actor(context)
    local owner = nil
    if ability then
        pcall(function()
            owner = ability:GetOwningActorFromActorInfo()
        end)
    end

    if config.verbose and rate_logged("cando-hit") then
        local cur = nil
        pcall(function()
            cur = out_param and out_param:get()
        end)
        log("CanDoReaction call owner=" .. name_of(owner)
            .. " cur=" .. tostring(cur))
    end

    local blocked = false
    if owner and is_pending_block(owner, channel) then
        blocked = true
        -- Keep the pending mark: CanDoReaction may be polled more than once
        -- for the same candidate before the caller consumes the out param.
        -- It is cleared by GatePRE allow (legit context) or by the leak hook.
    end
    if not blocked and config.dry_run then
        return
    end
    if blocked and not config.dry_run and out_param then
        local ok, err = pcall(function()
            out_param:set(false)
        end)
        if ok then
            if rate_logged("cando-block") then
                log("CanDoReaction out->false owner=" .. name_of(owner))
            end
        else
            log("CanDoReaction write failed :: " .. tostring(err))
        end
        return
    end
    if blocked and config.dry_run then
        if rate_logged("cando-wouldblock") then
            log("CanDoReaction would-block owner=" .. name_of(owner))
        end
    end
end

-- Leak detector stays read-only: if a would-block instance still reaches
-- activation, the new gates did not bite -> report so we pivot.
local function on_activate_leak(channel, context, ...)
    if not config.enabled then
        return
    end
    local ability = unwrap(context)
    if not ability then
        return
    end

    local owner = nil
    pcall(function()
        owner = ability:GetOwningActorFromActorInfo()
    end)

    local inst, victim = nil, nil
    pcall(function()
        local ed = ability.CurrentEventData
        if not ed or not ed.Instigator then
            ed = ability.TriggeringGameplayEventData
        end
        if ed then
            inst = try_actor(ed, "Instigator")
            victim = try_actor(ed, "Target")
        end
        if not inst then
            inst = ability.EventInstigator
        end
    end)

    -- Owner that we flagged gets cleared here: this activation is happening
    -- (gates did not stop it). Only the leak line remains.
    if owner then
        clear_pending_block(owner, channel)
    end

    local action, reason = decide(channel, owner, inst, victim)
    if not action then
        return
    end
    if action == "allow" then
        trace("Activate", action, reason, owner, inst, victim)
        return
    end
    stats.leaks = stats.leaks + 1
    local key = "leak:" .. tostring(reason)
    if rate_logged(key) then
        log("GATE-LEAK would-block reason=" .. tostring(reason)
            .. " channel=" .. tostring(channel)
            .. " owner=" .. name_of(owner)
            .. " inst=" .. name_of(inst)
            .. " victim=" .. name_of(victim)
            .. " (v" .. MOD_VERSION .. " gates did not stop this)")
    end
end

-- ---------------------------------------------------------------------------
-- Hook registration
-- ---------------------------------------------------------------------------

local attempted = {}
local cur_attempt = 0
local cur_final = false

local function register_dual(path, label, on_pre, on_post, quiet)
    if registered[path] then
        return true
    end
    local function pre_wrapper(context, ...)
        if not on_pre then return nil end
        local ok, ret = pcall(function(...)
            return on_pre(context, ...)
        end, ...)
        if not ok then
            if rate_logged("pre-fail:" .. label) then
                log("callback PRE failed " .. label .. " :: " .. tostring(ret))
            end
            return nil
        end
        return ret
    end
    local function post_wrapper(context, ...)
        if not on_post then return end
        local ok, err = pcall(function(...)
            on_post(context, ...)
        end, ...)
        if not ok then
            if rate_logged("post-fail:" .. label) then
                log("callback POST failed " .. label .. " :: " .. tostring(err))
            end
        end
    end
    local ok, error_message = pcall(function()
        RegisterHook(path, pre_wrapper, post_wrapper)
    end)
    if not ok then
        failed[path] = true
        if attempted[path] ~= cur_attempt then
            attempted[path] = cur_attempt
            if cur_final then
                log("hook unavailable " .. label .. " :: "
                    .. tostring(error_message))
            elseif not quiet then
                log("hook deferred " .. label
                    .. " (ability not loaded yet; retried automatically)")
            end
        end
        return false
    end
    failed[path] = nil
    registered[path] = true
    log("hook ok " .. label)
    return true
end

local function make_callbacks(channel, func_name)
    if func_name == "K2_ShouldAbilityRespondToEvent" then
        return function(context, actor_info_param, payload_param)
            return on_should_respond_pre(channel, context,
                actor_info_param, payload_param)
        end, function(context, actor_info_param, payload_param)
            on_should_respond_post(channel, context,
                actor_info_param, payload_param)
        end
    end
    if func_name == "K2_CanActivateAbility" then
        return function(context, actor_info_param)
            return on_can_activate_pre(channel, context, actor_info_param)
        end, nil
    end
    if func_name == "CanDoReaction" then
        return nil, function(context, out_param)
            on_can_do_reaction(channel, context, out_param)
        end
    end
    return nil, function(context, ...)
        on_activate_leak(channel, context, ...)
    end
end

-- Hook retries: assets stream in after the map loads, so the first pass usually
-- hits "not loaded yet".  Attempts are numbered so that only the LAST one is
-- allowed to report a hard failure.
local HOOK_RETRY_DELAYS = { 1000, 3000, 7000, 12000, 20000 }
local TOTAL_HOOK_ATTEMPTS = 1 + #HOOK_RETRY_DELAYS

local function register_hooks(attempt)
    cur_attempt = attempt or 1
    cur_final = cur_attempt >= TOTAL_HOOK_ATTEMPTS
    local targets = build_targets()
    current_targets = targets
    local order = {}
    for class_path in pairs(targets) do
        order[#order + 1] = class_path
    end
    table.sort(order)
    for _, class_path in ipairs(order) do
        local channel = targets[class_path]
        local quiet = true
        for _, known in ipairs(KNOWN_CLASSES) do
            if class_path == known then
                quiet = false
            end
        end
        for _, func_name in ipairs(FUNC_NAMES) do
            local pre, post = make_callbacks(channel, func_name)
            local label = channel .. "." .. class_short_name(class_path)
                .. "." .. func_name
            register_dual(class_path .. ":" .. func_name, label, pre, post, quiet)
        end
    end
end

-- ---------------------------------------------------------------------------
-- Health reporting (v1.5): make a broken/patched build visible.
-- ---------------------------------------------------------------------------

local status_state = nil

-- Below this age an idle guard is normal (nobody has shot at you yet), so the
-- alarming wording is withheld until a battle has plausibly happened.
local SILENT_WARN_AFTER_MS = 52000

-- Health is judged against the CURRENT target list, not against a running
-- tally of failures: a first pass that failed only because the ability was not
-- streamed in yet, and which a retry then fixed, is healthy.
local function hook_health()
    local ok, missing = 0, 0
    for class_path in pairs(current_targets) do
        for _, func_name in ipairs(FUNC_NAMES) do
            if registered[class_path .. ":" .. func_name] then
                ok = ok + 1
            else
                missing = missing + 1
            end
        end
    end
    return ok, missing
end

local function report_status(tag, elapsed_ms)
    if not config.enabled then
        return
    end
    local ok, missing = hook_health()
    local line = string.format(
        "STATUS %s hooks_ok=%d hooks_missing=%d gate_calls=%d blocks=%d "
            .. "allows=%d leaks=%d",
        tag, ok, missing, stats.gate_calls, stats.blocks, stats.allows,
        stats.leaks)
    local state
    if ok == 0 then
        state = "inactive"
    elseif stats.gate_calls == 0 then
        state = ((elapsed_ms or 0) >= SILENT_WARN_AFTER_MS) and "silent" or "idle"
    else
        state = "active"
    end
    if state == status_state then
        if state == "inactive" and rate_logged("inactive-reminder") then
            log("GUARD INACTIVE reminder - " .. line)
        end
        return
    end
    log(line)
    if state == "inactive" then
        log("GUARD INACTIVE - no retaliation hook is attached, so "
            .. "friendly-fire filtering is NOT running. This game build moved "
            .. "or renamed the retaliation abilities; send this line when "
            .. "reporting the issue: " .. line)
    elseif state == "silent" then
        log("GUARD SILENT - hooks are attached but no retaliation event has "
            .. "reached them on this map, so filtering may be inert on this "
            .. "game build. " .. line)
    elseif state == "active" then
        log("GUARD ACTIVE - retaliation filtering is running.")
    end
    status_state = state
end

-- Health checks are folded into the retry/status passes so that one map load
-- schedules few timers instead of a separate timer per probe.  The late passes
-- are what cover a full battle.
--
-- NOTE: this engine build logs "Lua::Registry::get_function_ref Ref was not
-- function" when a delayed callback's Lua ref goes stale (seen 2026-09-16).
-- That is an UE4SS-side complaint and the guard keeps running, but it is the
-- reason the number of scheduled callbacks is kept deliberately small.
local STATUS_DELAYS = { 8000, 52000, 112000, 232000 }

local generation = 0

local function on_map_loaded()
    generation = generation + 1
    local gen = generation
    stats.gate_calls, stats.blocks, stats.allows, stats.leaks = 0, 0, 0, 0
    status_state = nil
    discovery_scans = 0
    ExecuteInGameThread(function()
        if gen ~= generation then return end
        register_hooks(1)
    end)
    for index, ms in ipairs(HOOK_RETRY_DELAYS) do
        local delay = ms
        local attempt = index + 1
        pcall(function()
            ExecuteWithDelay(delay, function()
                if gen ~= generation then return end
                ExecuteInGameThread(function()
                    if gen ~= generation then return end
                    register_hooks(attempt)
                end)
            end)
        end)
    end
    for _, ms in ipairs(STATUS_DELAYS) do
        local delay = ms
        pcall(function()
            ExecuteWithDelay(delay, function()
                if gen ~= generation then return end
                ExecuteInGameThread(function()
                    if gen ~= generation then return end
                    report_status("t+" .. tostring(math.floor(delay / 1000))
                        .. "s", delay)
                end)
            end)
        end)
    end
end

load_config()
log("LOAD version=" .. MOD_VERSION
    .. " build=" .. BUILD_ID
    .. " enabled=" .. tostring(config.enabled)
    .. " dry_run=" .. tostring(config.dry_run)
    .. " verbose=" .. tostring(config.verbose)
    .. " auto_discover=" .. tostring(config.auto_discover)
    .. " class_routing=" .. tostring(config.class_routing))

local map_ok, map_error = pcall(function()
    RegisterLoadMapPostHook(on_map_loaded)
end)
if not map_ok then
    log("map hook failed :: " .. tostring(map_error))
end
