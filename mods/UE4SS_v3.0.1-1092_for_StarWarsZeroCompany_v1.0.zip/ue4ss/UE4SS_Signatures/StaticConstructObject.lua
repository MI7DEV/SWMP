-- STAR WARS Zero Company, Steam build 24874058, executable version 196320.
-- PDB-confirmed StaticConstructObject_Internal at RVA 0x1ACA0A0.
-- The RIP-relative displacement is wildcarded; the pattern has one retail match.
function Register()
    return "4C 8B DC 55 53 41 56 49 8D AB 28 FE FF FF 48 81 EC C0 02 00 00 48 8B 05 ?? ?? ?? ?? 48 33 C4 48 89 85 A0 01 00 00 8B 41 70"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end
