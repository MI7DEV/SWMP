-- STAR WARS Zero Company, Steam build 24874058, executable version 196320.
-- PDB-confirmed FName::FName(const wchar_t*, EFindName) at RVA 0x1852120.
-- This function-entry pattern has one match in the retail executable.
function Register()
    return "48 89 5C 24 08 57 48 83 EC 30 48 8B D9 41 8B F8 33 C9 4C 8B DA 44 8B D1 4C 8B CA 48 85 D2 74 23"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end
