UE4SS FOR STAR WARS ZERO COMPANY
Version 1.0

Unofficial compatibility build of UE4SS for the Steam release of
STAR WARS Zero Company.

INSTALLATION

Extract the contents of this archive into:

  ...\SteamLibrary\steamapps\common\Star Wars Zero Company\SWZeroCompany\Binaries\Win64\

The Win64 folder should then contain dwmapi.dll and the ue4ss folder.
Press F10 in-game to open the UE4SS console.

COMPATIBILITY

Tested with Steam build 24874058 on 27 August 2026.
Game updates may require a new compatibility build.
This is intended for the single-player game only.

UNINSTALLATION

Remove dwmapi.dll and the ue4ss folder. If you installed other UE4SS mods,
back them up before removing the folder.

CREDITS AND LICENCE

Based on UE4SS v3.0.1-1092-g0c5bff75:
https://github.com/UE4SS-RE/RE-UE4SS

UE4SS is distributed under the MIT License. The original licence is included
at ue4ss\LICENSE.

This is an unofficial game-specific compatibility build and is not affiliated
with UE4SS-RE, Bit Reactor, Electronic Arts, Lucasfilm, or Disney.

PATCH INFORMATION

The included UE4SS.dll changes two bytes in UE4SS's internal FName validation
branch so the verified constructor can initialize on this game. The game
executable is not modified or included.

Base UE4SS.dll:
  Version: v3.0.1-1092-g0c5bff75
  SHA-256: 58DB28775BECD6257DB7C3BE758FDE245B2A0D228B5F16DBAE12E062A5A952DA

Patched UE4SS.dll:
  File offsets: 0x34E550-0x34E551
  Bytes: 74 49 -> 90 90
  SHA-256: 8CB45C18230547A1EAD97BFEB34A2B5EF710B778890DDFC01877A7E9C61A07F4
