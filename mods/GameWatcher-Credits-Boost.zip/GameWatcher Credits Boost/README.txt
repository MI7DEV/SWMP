GameWatcher Credits Boost - Star Wars Zero Company
==================================================

Multiplies every credit reward in the game. Two variants; install ONE.

    x2 - Double Credits
    x4 - Quadruple Credits


INSTALL
-------
1. Pick one variant folder.
2. Copy the three files (.pak, .ucas, .utoc) into:

     Star Wars Zero Company\SWZeroCompany\Content\Paks\~mods\

   Create the "~mods" folder if it does not exist. The tilde is part of the
   name and matters - it controls load order.

3. Start the game. No launcher, no script extender, nothing else required.


UNINSTALL
---------
Delete the three files. Nothing else is touched, and no game file is modified,
so a Steam "Verify integrity of game files" is never needed.


WHAT IT CHANGES
---------------
Credit reward values only:

    Tiny          250  ->    500 (x2) /   1000 (x4)
    Small         500  ->   1000      /   2000
    Medium       1000  ->   2000      /   4000
    Large        1500  ->   3000      /   6000
    Huge         2500  ->   5000      /  10000
    Regional     2500  ->   5000      /  10000
    Pickpocket   150-300 -> 300-600   /  600-1200

Nothing else is altered - no intel, no XP, no difficulty, no items.


COMPATIBILITY
-------------
Safe to add or remove mid-playthrough; it changes reward values, not saves.

Conflicts with any other mod that edits the same files, i.e. anything under
Content/Game/GameData/Rewards/SharedRewards/Rewards_Credits_*.

Built against the game as of September 2026. A patch that changes reward values
could make this revert to vanilla numbers - it will not break the game, it just
stops having an effect.


CREDITS
-------
Made by GameWatcher. https://www.gamewatcher.com
