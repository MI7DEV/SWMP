GameWatcher - All Actions 1 AP - Star Wars Zero Company
=======================================================

Every ability costs 1 Action Point instead of 1, 2 or 3.

With a standard 3 AP pool that means three actions per turn regardless of what
you pick, so the expensive abilities stop being a once-a-turn luxury. It is a
real power increase, but it does not break the game the way free actions would.


INSTALL
-------
Copy the three files (.pak, .ucas, .utoc) into:

    Star Wars Zero Company\SWZeroCompany\Content\Paks\~mods\

Create the "~mods" folder if it does not exist. The tilde is part of the name
and controls load order.

Start the game. No script extender or launcher needed.


UNINSTALL
---------
Delete the three files. No game file is modified, so Steam's "Verify integrity
of game files" is never required.


WHAT IT CHANGES
---------------
The ability cost tables under Content/Game/GameData/DynamicGACosts/.
Every Action Point cost of 2 or 3 becomes 1. Costs already at 1 are untouched.

Advantage costs are deliberately left alone. Advantage is a separate resource
and flattening it as well made the game trivially easy in testing.

Nothing else is altered - no AP pool, no damage, no health, no rewards.


COMPATIBILITY
-------------
Works with an existing save; costs are looked up when an ability is used, not
baked into the save file. Safe to add or remove mid-playthrough.

Conflicts with any other mod editing the same cost tables.

Built against the game as of September 2026. A patch that changes these tables
could make this revert to vanilla costs - it will not break anything, it just
stops having an effect.


CREDITS
-------
Made by GameWatcher. https://www.gamewatcher.com
