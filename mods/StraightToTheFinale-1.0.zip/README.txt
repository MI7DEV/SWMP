STRAIGHT TO THE FINALE
A Star Wars Zero Company mod
Version 1.0


WHAT IT DOES

Start a new campaign and you are dropped into the last mission of the game
instead of the Serolonis tutorial. No tutorial, no build-up: your level-one
squad lands on Cindermoor for the endgame.

The final boss has been replaced. Fathom's slot is now filled by the Separatist
Boss Gunship - a non-humanoid enemy that is fully finished in the game files but
never used anywhere in the shipped campaign. It keeps the boss's normal 350 HP,
so it is still a real fight.

To make five endgame encounters survivable with starting gear, every non-boss
enemy in the game is set to 1 HP ("glass mooks"). Bosses are untouched.


INSTALL

1. Find your game folder, then go into:
     SWZeroCompany\Content\Paks\
2. Create a folder called  ~mods  if it isn't there already (the ~ matters).
3. Copy StraightToTheFinale_P.pak, .ucas and .utoc into it. All three files.
4. Start a NEW CAMPAIGN. The map is chosen when the mission launches, so an
   existing save will not pick this up.

No UE4SS, script extender or mod manager is required.


OPTIONAL: HARD MODE

Optional-HardMode contains the same mod with the 1 HP change left out. Enemies
keep their normal health, which makes the finale genuinely punishing with a
level-one squad - most likely unwinnable.

To use it, replace the three files you installed in step 3 with the three from
Optional-HardMode. They have the same filenames, so just overwrite. Do not
install both.


UNINSTALL

Delete the files you copied from ~mods. Nothing else is touched, and no game
files are modified.


KNOWN QUIRKS

- The 1 HP change is global. It applies to every mission, not only the finale.
- The gunship is a flying unit dropped into a ground boss slot. It may hover
  oddly, sit inside geometry, or path strangely. That is the engine, not a
  broken install.
- The mission runs the finale's own objectives and dialogue, so the story will
  reference events you have not played.
- This is a sandbox, not a balanced campaign. Treat it as a boss-rush toy.


COMPATIBILITY

Built against the UE 5.6 retail build. Conflicts with any other mod that edits
MM_01_010_SerolonisJob, SG_Coil_Boss_Fathom_1x, or the
Attributes_Enemy_*_Health assets.
