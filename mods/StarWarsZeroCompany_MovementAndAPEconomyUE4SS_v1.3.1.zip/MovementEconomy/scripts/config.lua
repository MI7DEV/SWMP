-- author: Caites
return {
    movementPerAP            = 750.0, -- movement distane per AP, default is 500
    movementApplyTo          = "heroes", -- mode - to whom apply movement per AP changes, you can set it too heroes, enemies, all

    additionalMovementPoints = 1, -- number of AP for movement over normal 3 points - set from 1 to 3
    additionalApplyTo        = "heroes", -- mode - to whom apply the change, you can set it too heroes, enemies, all

    intervalMs               = 500, -- how often to check action points during a mission
    moveVerifyMs             = 5000, -- how often to re-check movement per AP during a mission
    rescanMs                 = 10000, -- during a mission, how often to pick up newly spawned units

    debug                    = false,
}
