-- author: Caites

local CFG = require("config")

local MOVE, MOVE_TO  = CFG.movementPerAP, CFG.movementApplyTo
local ADD_TO         = CFG.additionalApplyTo
local ADD            = math.max(0, math.min(3, math.floor(CFG.additionalMovementPoints or 0)))
local DEBUG          = CFG.debug
local INTERVAL       = CFG.intervalMs or 500
local MOVE_VERIFY_MS = CFG.moveVerifyMs or 5000
local RESCAN_MS      = CFG.rescanMs or 10000

local MAX_TRIES  = 5
local GATE_MS    = 15000
local TGS_CLASS  = "TacticalGameState"
local CS_CLASS   = "BitReactorCombatSet"
local TGS_PATH   = "/Script/BitReactorGame.TacticalGameState"
local CS_PATH    = "/Script/BitReactorGame.BitReactorCombatSet"

local find, thread = FindAllOf, ExecuteInGameThread

local function log(s) print("[ZC] " .. s .. "\n") end
local function dbg(s) if DEBUG then log(s) end end

local function valid(o)
    if o == nil then return false end
    local ok, r = pcall(function() return o:IsValid() end)
    return ok and r == true
end

local function nameOf(cs)
    local ok, n = pcall(function() return cs:GetOuter():GetFName():ToString() end)
    if ok then return n end
end

local function kindOf(n)
    if n:find("Char_Hero", 1, true) then return "hero" end
    if n:find("Char_Enemy", 1, true) then return "enemy" end
    if n:find("Char_", 1, true) then return "other" end
end

local function match(mode, kind)
    return mode == "all" or (mode == "heroes" and kind == "hero")
                         or (mode == "enemies" and kind == "enemy")
end

local function readv(cs, attr)
    local ok, v = pcall(function() return cs[attr].CurrentValue end)
    if ok then return v end
end

local function write(cs, attr, v)
    return (pcall(function()
        local d = cs[attr]
        d.BaseValue = v
        d.CurrentValue = v
    end))
end

local function nowMs() return os.clock() * 1000.0 end

local inMission = false
local tgs       = nil
local entries   = {}
local known     = {}
local pending   = {}
local lastMove  = 0
local lastRe    = 0
local scans     = 0
local notified  = false

local function keyOf(cs)
    local ok, k = pcall(function() return cs:GetFullName() end)
    return ok and k or nil
end

local function track(cs)
    if not valid(cs) then return nil end
    local key = keyOf(cs)
    if not key or known[key] then return nil end
    local n = nameOf(cs)
    local k = n and kindOf(n)
    if not k then return nil end

    local e = {
        obj       = cs,
        key       = key,
        name      = n,
        kind      = k,
        doMove    = MOVE ~= nil and match(MOVE_TO, k),
        doAdd     = ADD > 0 and match(ADD_TO, k),
        lastAP    = nil,
        moveTries = 0,
        apTries   = 0,
    }
    known[key] = e
    entries[#entries + 1] = e
    return e
end

local function forget()
    entries, known, pending = {}, {}, {}
end

local function applyMove(e)
    if not e.doMove or e.moveTries >= MAX_TRIES then return end
    local cur = readv(e.obj, "MovementPerAP")
    if cur == MOVE then
        e.moveTries = 0
        return
    end
    write(e.obj, "MovementPerAP", MOVE)
    if readv(e.obj, "MovementPerAP") == MOVE then
        e.moveTries = 0
        dbg(("%s MovementPerAP -> %s"):format(e.name, tostring(MOVE)))
    else
        e.moveTries = e.moveTries + 1
        if e.moveTries >= MAX_TRIES then
            dbg(("%s MovementPerAP will not stick, giving up"):format(e.name))
        end
    end
end

local function applyAP(e)
    if not e.doAdd or e.apTries >= MAX_TRIES then return end
    local v = readv(e.obj, "ActionPoints")
    if not v then return end

    if (e.lastAP == nil or v > e.lastAP) and v > 0 then
        local target = v + ADD
        write(e.obj, "ActionPoints", target)
        local got = readv(e.obj, "ActionPoints")
        if got == target then
            e.apTries = 0
            e.lastAP = target
            dbg(("%s AP %s +%d -> %s"):format(e.name, tostring(v), ADD, tostring(target)))
        else
            e.apTries = e.apTries + 1
            e.lastAP = got or v
            if e.apTries >= MAX_TRIES then
                dbg(("%s ActionPoints will not stick, giving up"):format(e.name))
            end
        end
    else
        e.lastAP = v
    end
end

local function sweep()
    scans = scans + 1
    local sets = find(CS_CLASS)
    if not sets then return 0 end
    local added = 0
    for i = 1, #sets do
        if track(sets[i]) then added = added + 1 end
    end
    return added
end

local function registerNotify()
    if notified then return end
    local n = 0
    if pcall(NotifyOnNewObject, CS_PATH, function(obj)
        pcall(function() pending[#pending + 1] = obj end)
    end) then n = n + 1 end
    if pcall(NotifyOnNewObject, TGS_PATH, function(obj)
        pcall(function() if valid(obj) then tgs = obj end end)
    end) then n = n + 1 end
    notified = true
    dbg(("spawn notifications registered: %d"):format(n))
end

local function missionActive()
    if valid(tgs) then return true end
    tgs = nil
    return false
end

local function enterMission()
    inMission = true
    forget()
    local n = sweep()
    lastMove, lastRe = nowMs(), nowMs()
    for i = 1, #entries do applyMove(entries[i]) end
    log(("mission started - tracking %d units"):format(n))
end

local function leaveMission()
    inMission = false
    forget()
    log("mission ended - idle")
end

local function absorb()
    if #pending == 0 then return end
    for i = 1, #pending do
        local e = track(pending[i])
        if e then applyMove(e) end
    end
    pending = {}
end

local function tick()
    if not missionActive() then
        leaveMission()
        return
    end

    local now = nowMs()
    absorb()

    if now - lastRe >= RESCAN_MS then
        lastRe = now
        sweep()
    end

    local verifyMove = (now - lastMove) >= MOVE_VERIFY_MS
    if verifyMove then lastMove = now end

    local i, n = 1, #entries
    while i <= n do
        local e = entries[i]
        if not valid(e.obj) then
            known[e.key] = nil
            entries[i] = entries[n]
            entries[n] = nil
            n = n - 1
        else
            if verifyMove then applyMove(e) end
            applyAP(e)
            i = i + 1
        end
    end
end

LoopAsync(INTERVAL, function()
    if inMission then thread(tick) end
    return false
end)

local function evaluateGate()
    if not valid(tgs) then
        local ok, o = pcall(FindFirstOf, TGS_CLASS)
        tgs = (ok and valid(o)) and o or nil
    end
    local active = missionActive()
    if active and not inMission then enterMission()
    elseif not active and inMission then leaveMission() end
end

pcall(RegisterLoadMapPostHook, function()
    ExecuteWithDelay(3000, function() thread(evaluateGate) end)
end)

thread(function()
    registerNotify()
    evaluateGate()
end)

LoopAsync(GATE_MS, function()
    if not inMission then thread(evaluateGate) end
    return false
end)

local function status()
    log(("inMission=%s units=%d sweeps=%d pending=%d")
        :format(tostring(inMission), #entries, scans, #pending))
    for i = 1, #entries do
        local e = entries[i]
        log(("  %s [%s] move=%s ap=%s")
            :format(e.name, e.kind,
                    tostring(readv(e.obj, "MovementPerAP")),
                    tostring(readv(e.obj, "ActionPoints"))))
    end
end

do
    local handler = function(_, _, _) thread(status) return true end
    if not pcall(RegisterConsoleCommandGlobalHandler, "zc_status", handler) then
        pcall(RegisterConsoleCommandHandler, "zc_status", handler)
    end
end

log(("loaded: movePerAP=%s(%s) addMove=+%d(%s)")
    :format(tostring(MOVE), tostring(MOVE_TO), ADD, tostring(ADD_TO)))
