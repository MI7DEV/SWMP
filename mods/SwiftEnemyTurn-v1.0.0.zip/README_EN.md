# Swift Enemy Turn

**Star Wars: Zero Company** UE4SS mod · Version **1.0.0**

Speeds up the **enemy turn** by starting the next AI action without waiting for the previous cinematic to finish, and by advancing once the ability has committed on the server.

Requires the game-specific **UE4SS** build (not bundled). Safe to use with **SwiftActions** and **SwiftAssistShots**: those speed up player commits and assist shots; this one only touches the AI turn director.

## Features

- **Next enemy sooner** — shortens Turn Director `WatchUnitTime` (default 0.15s) so the next plan index can start before the previous presentation ends.
- **Advance after commit** — caps `WaitForStoryAbilitiesToFinish` (default 0.45s) instead of waiting for the full cinematic.
- **Simultaneous-story cap** — `StartAbilitiesSimultaneously` wait is capped at about 1.25s.
- **Skip AI cine beats** — `SkipCineBeats` turns off cinematic camera beats; gameplay montages still play.
- **Overlap animations** — `KeepPlayingOnStateEnd` tries to leave choreographed sequences running when the story node exits.
- **Tunable** — all of the above in `config.ini`.

Does not change damage, AI decisions, or saves. Presentation timing only.

## Install

1. Install [UE4SS for Star Wars Zero Company](https://www.nexusmods.com/starwarszerocompany/mods).
2. Close the game.
3. Copy the **`SwiftEnemyTurn`** folder into:

   `SWZeroCompany\Binaries\Win64\ue4ss\Mods\`

4. Edit `ue4ss\Mods\mods.txt` and add this line **above** `Keybinds : 1`:

   `SwiftEnemyTurn : 1`

5. Launch the game. `UE4SS.log` should show `Starting Lua mod 'SwiftEnemyTurn'`. Combat maps register the remaining hooks (`HOOK ok`).

## Uninstall

Delete `ue4ss\Mods\SwiftEnemyTurn` and remove its line from `mods.txt`.

## Config

Edit `SwiftEnemyTurn\config.ini`:

| Key | Default | Effect |
|---|---|---|
| `WatchUnitDelay` | 0.15 | How soon the next enemy may start |
| `WaitForStoryTimeout` | 0.45 | Max wait after abilities have started |
| `SimultaneousTimeout` | 1.25 | Cap for the all-at-once story node |
| `SkipCineBeats` | true | Skip AI cinematic camera beats |
| `KeepPlayingOnStateEnd` | true | Keep sequences playing after the node exits |

If death/hit reacts clip, raise `WaitForStoryTimeout` to `0.8`–`1.2`. For more overlap, lower `WatchUnitDelay` to `0`–`0.05`.

## Compatibility

- Game: *Star Wars: Zero Company*
- Requires the game-specific UE4SS compatibility build
- Coexists with SwiftActions / SwiftAssistShots and pak mods that do not hook the same Turn Director nodes

## License

Fan mod for personal and community non-commercial use. Game assets remain © their respective owners.
