local MOD_NAME = "SwiftEnemyTurn"
local BUILD_ID = "enemy-async-v1-20260901"

local DEFAULT_ENABLED = true
local DEFAULT_WATCH_UNIT_DELAY = 0.15
local DEFAULT_WAIT_FOR_STORY_TIMEOUT = 0.45
local DEFAULT_SIMULTANEOUS_TIMEOUT = 1.25
local DEFAULT_SKIP_CINE_BEATS = true
local DEFAULT_KEEP_PLAYING = true

local RUN_BY_PLAN_BEGIN =
    "/Game/Game/Cinematics/Blueprints/TurnDirectorStateMachines/States/SMState_EnemyTurnStoryNode_RunAbilitiesByPlanIndex.SMState_EnemyTurnStoryNode_RunAbilitiesByPlanIndex_C:OnStateBegin"
local SIMULTANEOUS_BEGIN =
    "/Game/Game/Cinematics/Blueprints/TurnDirectorStateMachines/States/SMState_EnemyTurnStoryNode_StartAbilitiesSimultaneously.SMState_EnemyTurnStoryNode_StartAbilitiesSimultaneously_C:OnStateBegin"
local WAIT_STORY_BEGIN =
    "/Game/Game/Core/Prototypes/EnemyTurn/Sequences/Nodes/SMState_WaitForStoryAbilitiesToFinish.SMState_WaitForStoryAbilitiesToFinish_C:OnStateBegin"
local WAIT_STORY_UPDATE =
    "/Game/Game/Core/Prototypes/EnemyTurn/Sequences/Nodes/SMState_WaitForStoryAbilitiesToFinish.SMState_WaitForStoryAbilitiesToFinish_C:OnStateUpdate"
local WAIT_STORY_IS_FINISHED =
    "/Game/Game/Core/Prototypes/EnemyTurn/Sequences/Nodes/SMState_WaitForStoryAbilitiesToFinish.SMState_WaitForStoryAbilitiesToFinish_C:IsPresentationFinished"
local PRESENTATION_REQUEST =
    "/Game/Game/Core/Blueprints/BP_AbilitySequenceManager.BP_AbilitySequenceManager_C:TurnDirectorRequestAbilityPresentation"
local ABILITY_COMMITTED =
    "/Game/Game/Core/Blueprints/BP_AbilitySequenceManager.BP_AbilitySequenceManager_C:OnAbilityCommitted"
local SHOULD_PLAY_CINE =
    "/Game/Game/Core/Blueprints/BP_AbilitySequenceManager.BP_AbilitySequenceManager_C:ShouldPlayExecutionCineBeat"
local IS_PLAYER_TURN =
    "/Game/Game/Core/Blueprints/BP_AbilitySequenceManager.BP_AbilitySequenceManager_C:IsPlayerTurn"
local CHOREO_BEGIN =
    "/Game/Game/Cinematics/Blueprints/Stage/StateMachine/SMstate_PlayChoreographedSequence.SMstate_PlayChoreographedSequence_C:OnStateBegin"

local registered_hooks = {}
local config = {
    enabled = DEFAULT_ENABLED,
    watch_unit_delay = DEFAULT_WATCH_UNIT_DELAY,
    wait_for_story_timeout = DEFAULT_WAIT_FOR_STORY_TIMEOUT,
    simultaneous_timeout = DEFAULT_SIMULTANEOUS_TIMEOUT,
    skip_cine_beats = DEFAULT_SKIP_CINE_BEATS,
    keep_playing = DEFAULT_KEEP_PLAYING,
    path = "not found",
}

local enemy_turn_until = 0.0
local last_commit_at = 0.0
local logged_seq_fields = false
local wait_story_started_at = 0.0

local function log(message)
    print(string.format("[%s %.3f] %s\n", MOD_NAME, os.clock(), message))
end

local function unwrap(value)
    if not value then
        return nil
    end

    local ok, unwrapped = pcall(function()
        return value:get()
    end)

    if ok and unwrapped then
        return unwrapped
    end

    return value
end

local function object_label(value)
    local object = unwrap(value)
    if not object then
        return "nil"
    end

    local ok, full_name = pcall(function()
        return object:GetFullName()
    end)

    if ok and full_name ~= nil then
        return tostring(full_name)
    end

    return tostring(object)
end

local function trim(value)
    return (value or ""):gsub("^%s+", ""):gsub("%s+$", "")
end

local function parse_bool(value)
    local lower = string.lower(trim(value))
    if lower == "true" or lower == "1" or lower == "yes" or lower == "on" then
        return true
    end
    if lower == "false" or lower == "0" or lower == "no" or lower == "off" then
        return false
    end
    return nil
end

local function config_path()
    local ok, directories = pcall(IterateGameDirectories)
    local win64 = ok and directories and directories.Game
        and directories.Game.Binaries and directories.Game.Binaries.Win64

    if not win64 then
        return nil
    end

    return win64.__absolute_path .. "\\ue4ss\\Mods\\" .. MOD_NAME .. "\\config.ini"
end

local function load_config()
    local path = config_path()
    if not path then
        log("CONFIG unavailable; using defaults")
        return
    end

    config.path = path
    local file = io.open(path, "r")
    if not file then
        log("CONFIG missing; using defaults path=" .. path)
        return
    end

    for raw_line in file:lines() do
        local line = trim(raw_line:gsub("[;#].*$", ""))
        local key, value = line:match("^([^=]+)=(.*)$")
        if key and value then
            key = string.lower(trim(key))
            value = trim(value)
            if key == "enabled" then
                local parsed = parse_bool(value)
                if parsed ~= nil then
                    config.enabled = parsed
                end
            elseif key == "watchunitdelay" then
                local parsed = tonumber(value)
                if parsed and parsed >= 0 then
                    config.watch_unit_delay = parsed
                end
            elseif key == "waitforstorytimeout" then
                local parsed = tonumber(value)
                if parsed and parsed >= 0 then
                    config.wait_for_story_timeout = parsed
                end
            elseif key == "simultaneoustimeout" then
                local parsed = tonumber(value)
                if parsed and parsed >= 0 then
                    config.simultaneous_timeout = parsed
                end
            elseif key == "skipcinebeats" then
                local parsed = parse_bool(value)
                if parsed ~= nil then
                    config.skip_cine_beats = parsed
                end
            elseif key == "keepplayingonstateend" then
                local parsed = parse_bool(value)
                if parsed ~= nil then
                    config.keep_playing = parsed
                end
            end
        end
    end

    file:close()
    log("CONFIG loaded enabled=" .. tostring(config.enabled)
        .. " watch=" .. tostring(config.watch_unit_delay)
        .. " story_timeout=" .. tostring(config.wait_for_story_timeout)
        .. " sim_timeout=" .. tostring(config.simultaneous_timeout)
        .. " skip_cine=" .. tostring(config.skip_cine_beats)
        .. " keep_playing=" .. tostring(config.keep_playing)
        .. " path=" .. config.path)
end

local function in_enemy_turn()
    return os.clock() < enemy_turn_until
end

local function mark_enemy_turn()
    enemy_turn_until = os.clock() + 8.0
end

local function set_number(object, field_name, value)
    local ok, error_message = pcall(function()
        object[field_name] = value
    end)

    if not ok then
        log("write failed " .. field_name .. " :: " .. tostring(error_message))
        return false
    end

    return true
end

local function set_bool(object, field_name, value)
    local ok, error_message = pcall(function()
        object[field_name] = value
    end)

    if not ok then
        log("write failed " .. field_name .. " :: " .. tostring(error_message))
        return false
    end

    return true
end

local function read_field(object, field_name)
    local ok, value = pcall(function()
        return object[field_name]
    end)

    if ok then
        return value
    end

    return nil
end

local function maybe_broadcast(object, field_name)
    local ok, error_message = pcall(function()
        local delegate = object[field_name]
        if delegate ~= nil then
            if type(delegate) == "function" then
                delegate()
            elseif delegate.Broadcast then
                delegate:Broadcast()
            end
        end
    end)

    if not ok then
        log("broadcast failed " .. field_name .. " :: " .. tostring(error_message))
        return false
    end

    return true
end

local function apply_watch_times(context)
    if not config.enabled then
        return
    end

    local state = unwrap(context)
    if not state then
        return
    end

    mark_enemy_turn()
    local delay = config.watch_unit_delay
    set_number(state, "WatchUnitTimeMin", delay)
    set_number(state, "WatchUnitTimeMax", delay)
    set_number(state, "WatchUnitTime", delay)
    set_number(state, "WatchedUnitTime", delay)
    log("WATCH applied delay=" .. tostring(delay) .. " state=" .. object_label(state))
end

local function apply_simultaneous_timeout(context)
    if not config.enabled then
        return
    end

    local state = unwrap(context)
    if not state then
        return
    end

    mark_enemy_turn()
    set_number(state, "Timeout", config.simultaneous_timeout)
    log("SIM timeout=" .. tostring(config.simultaneous_timeout)
        .. " state=" .. object_label(state))
end

local function apply_wait_story_timeout(context)
    if not config.enabled then
        return
    end

    local state = unwrap(context)
    if not state then
        return
    end

    mark_enemy_turn()
    wait_story_started_at = os.clock()
    set_number(state, "TimeOut", config.wait_for_story_timeout)
    set_number(state, "Timeout", config.wait_for_story_timeout)
    log("STORY timeout=" .. tostring(config.wait_for_story_timeout)
        .. " state=" .. object_label(state))
end

local function maybe_finish_wait_story(context)
    if not config.enabled or wait_story_started_at <= 0.0 then
        return
    end

    if os.clock() < wait_story_started_at + config.wait_for_story_timeout then
        return
    end

    local state = unwrap(context)
    if not state then
        return
    end

    maybe_broadcast(state, "AllAbilitiesFinished")
    maybe_broadcast(state, "TimeoutOccured")
    wait_story_started_at = 0.0
    log("STORY force-finish state=" .. object_label(state))
end

local function force_is_finished(result)
    if not config.enabled or not result then
        return
    end

    if wait_story_started_at > 0.0
        and os.clock() < wait_story_started_at + config.wait_for_story_timeout then
        return
    end

    pcall(function()
        result:set(true)
    end)
end

local function describe_sequence_manager(seq)
    if logged_seq_fields or not seq then
        return
    end

    logged_seq_fields = true
    log("SEQ IsPlayerTurn=" .. tostring(read_field(seq, "IsPlayerTurn"))
        .. " bAllowCineBeatsDuringAITurn=" .. tostring(read_field(seq, "bAllowCineBeatsDuringAITurn"))
        .. " bAllowCinematicStateMachine=" .. tostring(read_field(seq, "bAllowCinematicStateMachine"))
        .. " bUnrestrictPlayingAnimations=" .. tostring(read_field(seq, "bUnrestrictPlayingAnimations"))
        .. " ProcessingAbility=" .. object_label(read_field(seq, "ProcessingAbility")))
end

local function on_presentation_request(context)
    if not config.enabled then
        return
    end

    local seq = unwrap(context)
    describe_sequence_manager(seq)
    if not seq then
        return
    end

    local player_turn = read_field(seq, "IsPlayerTurn")
    if player_turn == true then
        return
    end

    mark_enemy_turn()
    if config.skip_cine_beats then
        set_bool(seq, "bAllowCineBeatsDuringAITurn", false)
        set_bool(seq, "bAllowCineBeatsOverride", false)
    end

    if config.keep_playing then
        set_bool(seq, "bUnrestrictPlayingAnimations", true)
        set_bool(seq, "bAllowCinematicStateMachine", true)
    end
end

local function on_ability_committed(context)
    if not config.enabled then
        return
    end

    last_commit_at = os.clock()
    mark_enemy_turn()
    log("COMMIT seq=" .. object_label(context))
end

local function suppress_cine_beat(_, should_play)
    if not config.enabled or not config.skip_cine_beats or not in_enemy_turn() then
        return
    end

    if not should_play then
        return
    end

    pcall(function()
        should_play:set(false)
    end)
end

local function on_player_turn_query(_, is_turn)
    if not is_turn then
        return
    end

    local ok, value = pcall(function()
        return is_turn:get()
    end)

    if ok and value == false then
        mark_enemy_turn()
    end
end

local function on_choreo_begin(context)
    if not config.enabled or not in_enemy_turn() then
        return
    end

    local state = unwrap(context)
    if not state then
        return
    end

    if config.keep_playing then
        set_bool(state, "bStopSequenceOnStateEnd", false)
    end
end

local function register_hook(path, label, on_pre, on_post)
    if registered_hooks[path] then
        return true
    end

    local ok, error_message = pcall(function()
        RegisterHook(path, function(context, ...)
            if on_pre then
                local callback_ok, callback_error = pcall(on_pre, context, ...)
                if not callback_ok then
                    log("callback PRE failed " .. label .. " :: " .. tostring(callback_error))
                end
            end
        end, function(context, ...)
            if on_post then
                local callback_ok, callback_error = pcall(on_post, context, ...)
                if not callback_ok then
                    log("callback POST failed " .. label .. " :: " .. tostring(callback_error))
                end
            end
        end)
    end)

    if not ok then
        log("HOOK unavailable " .. label .. " :: " .. tostring(error_message))
        return false
    end

    registered_hooks[path] = true
    log("HOOK ok " .. label)
    return true
end

local function register_hooks()
    register_hook(RUN_BY_PLAN_BEGIN, "RunAbilitiesByPlanIndex.OnStateBegin", apply_watch_times, nil)
    register_hook(SIMULTANEOUS_BEGIN, "StartAbilitiesSimultaneously.OnStateBegin", apply_simultaneous_timeout, nil)
    register_hook(WAIT_STORY_BEGIN, "WaitForStoryAbilitiesToFinish.OnStateBegin", apply_wait_story_timeout, nil)
    register_hook(WAIT_STORY_UPDATE, "WaitForStoryAbilitiesToFinish.OnStateUpdate", maybe_finish_wait_story, nil)
    register_hook(WAIT_STORY_IS_FINISHED, "WaitForStoryAbilitiesToFinish.IsPresentationFinished", function(_, result)
        force_is_finished(result)
    end, function(_, result)
        force_is_finished(result)
    end)
    register_hook(PRESENTATION_REQUEST, "TurnDirectorRequestAbilityPresentation", on_presentation_request, nil)
    register_hook(ABILITY_COMMITTED, "OnAbilityCommitted", on_ability_committed, nil)
    register_hook(SHOULD_PLAY_CINE, "ShouldPlayExecutionCineBeat", function(context, should_play)
        suppress_cine_beat(context, should_play)
    end, function(context, should_play)
        suppress_cine_beat(context, should_play)
    end)
    register_hook(IS_PLAYER_TURN, "IsPlayerTurn", nil, on_player_turn_query)
    register_hook(CHOREO_BEGIN, "PlayChoreographedSequence.OnStateBegin", on_choreo_begin, nil)
end

load_config()
log("LOAD build=" .. BUILD_ID
    .. " enabled=" .. tostring(config.enabled)
    .. " watch=" .. tostring(config.watch_unit_delay)
    .. " story_timeout=" .. tostring(config.wait_for_story_timeout)
    .. " sim_timeout=" .. tostring(config.simultaneous_timeout))

local ok, error_message = pcall(function()
    RegisterLoadMapPostHook(function()
        ExecuteInGameThread(register_hooks)
    end)
end)

if not ok then
    log("LOAD map hook failed :: " .. tostring(error_message))
end
