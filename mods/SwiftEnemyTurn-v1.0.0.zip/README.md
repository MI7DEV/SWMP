# 星球大战：零号连队 MOD — 敌人回合异步

版本：**1.0.0**

敌方回合不再严格「一个演完再演下一个」。技能在服务端结算后即可推进下一名敌人，并尽量让上一个动画继续播，从而缩短敌方回合等待。

需要游戏专用 **UE4SS**（不随本包附带）。与 **SwiftActions** / **SwiftAssistShots** 可同时使用：前两者加速玩家出手与助攻镜头，本 MOD 只管敌方回合。

## 功能

- **提前轮到下一名敌人**：缩短 Turn Director 的 `WatchUnitTime`（默认 0.15 秒），不必等上一段完整演出结束。
- **结算即推进**：压缩 `WaitForStoryAbilitiesToFinish` 等待（默认 0.45 秒），不等完整 cinematic。
- **齐射模板封顶**：`StartAbilitiesSimultaneously` 最多再等约 1.25 秒。
- **关掉敌方电影机位**：`SkipCineBeats`，Gameplay 蒙太奇仍播放。
- **尽量叠动画**：过场离开状态时不停序列（`KeepPlayingOnStateEnd`），上一个动作可与下一个重叠。
- **可调**：全部选项在 `config.ini`。

不改伤害、AI 决策或存档，只动演出时序。

## 安装

1. 已安装 [UE4SS for Star Wars Zero Company](https://www.nexusmods.com/starwarszerocompany/mods)。
2. 关闭游戏。
3. 将 **`SwiftEnemyTurn`** 整个文件夹复制到：

   `SWZeroCompany\Binaries\Win64\ue4ss\Mods\`

4. 编辑 `ue4ss\Mods\mods.txt`，在 `Keybinds : 1` **之上**增加一行：

   `SwiftEnemyTurn : 1`

5. 启动游戏。`UE4SS.log` 应出现 `Starting Lua mod 'SwiftEnemyTurn'`；进战斗图后会有 `HOOK ok`。

## 卸载

删除 `ue4ss\Mods\SwiftEnemyTurn`，并从 `mods.txt` 去掉对应行。

## 调节

编辑 `SwiftEnemyTurn\config.ini`：

| 项 | 默认 | 作用 |
|---|---|---|
| `WatchUnitDelay` | 0.15 | 下一名敌人何时可以开始（越小越齐） |
| `WaitForStoryTimeout` | 0.45 | 结算后最多再等多久演出 |
| `SimultaneousTimeout` | 1.25 | 齐射故事节点等待封顶 |
| `SkipCineBeats` | true | 跳过敌方电影机位 |
| `KeepPlayingOnStateEnd` | true | 离开节点时不停过场 |

死亡/受击被切掉时，把 `WaitForStoryTimeout` 调到 `0.8`～`1.2`。想更齐射，把 `WatchUnitDelay` 降到 `0`～`0.05`。

## 兼容性

- 游戏：*Star Wars: Zero Company*
- 依赖：该游戏专用 UE4SS 兼容构建
- 与 SwiftActions、SwiftAssistShots 以及不钩同一 Turn Director 节点的 pak MOD 一般可共存

## 许可证

仅供个人与社区非商业使用；游戏资产归相应权利方所有。
