local defaults = {
    keys = {
        toggle_time_lock = "F4",
        advance_day      = "F2",
        force_win        = "F8",
        clear_blocks     = "F3",
    },
    auto_unlock_in_den = true,
    enable_force_win   = true,
    message_seconds    = 4,
    message_x          = 80,
    message_y          = 140,
}

local cfg = defaults
do
    local ok, loaded = pcall(require, "config")
    if ok and type(loaded) == "table" then
        cfg = loaded
        for k, v in pairs(defaults) do
            if cfg[k] == nil then cfg[k] = v end
        end
        cfg.keys = cfg.keys or {}
        for k, v in pairs(defaults.keys) do
            if cfg.keys[k] == nil then cfg.keys[k] = v end
        end
    else
        print("[NoDayCost] config.lua not loaded, using defaults\n")
    end
end

local BLOCK_KEY   = "ZC_NoDayCost"
local TURN_CDO    = "/Script/Bruno.Default__BrunoStrategyTurnManager"
local DEN_STATE   = "GMState_Headquarters_ExplorePhase_C"
local ENDTURN     = "GMState_Headquarters_EndTurn_C"
local WIN_STATE   = "GMState_TacticalVictory_C"
local LAYOUT      = "WBP_OverallUILayout_C"

local function Key4(name)
    local k = Key[name]
    if not k then print("[NoDayCost] unknown key '" .. tostring(name) .. "'\n") end
    return k
end

local function WCO()
    local pc = FindFirstOf("PlayerController")
    if pc and pc:IsValid() then return pc end
end

local function IsLive(o)
    if not o or not o:IsValid() then return false end
    local n = o:GetFullName()
    return not n:find("Default__") and not n:find("TEMPLATE_")
end

local function TurnMgr()
    local cdo, pc = StaticFindObject(TURN_CDO), WCO()
    if not cdo or not pc then return nil end
    local ok, mgr = pcall(function() return cdo:GetStrategyTurnManager(pc) end)
    if ok and mgr and mgr:IsValid() then return mgr end
end

local function FindState(cls)
    for _, o in ipairs(FindObjects(0, cls, "", 0, 0, false) or {}) do
        if IsLive(o) then return o, o:GetOuter() end
    end
end

local function ActiveState()
    local _, sm = FindState(DEN_STATE)
    if not sm or not sm:IsValid() then return "?" end
    local ok, st = pcall(function() return sm:GetSingleActiveStateInstance(true) end)
    if ok and st and st:IsValid() then return st:GetClass():GetFName():ToString() end
    return "?"
end

local function IsLocked()
    local m = TurnMgr()
    if not m then return false end
    local ok, held = pcall(function() return m:HasTurnBlockingKey(BLOCK_KEY) end)
    return ok and held == true
end

local Toast = { widget = nil, token = 0 }

local function Layout()
    for _, w in ipairs(FindObjects(0, LAYOUT, "", 0, 0, false) or {}) do
        if IsLive(w) then
            local ok, inv = pcall(function() return w:IsInViewport() end)
            if ok and inv then return w end
        end
    end
end

local function ToastWidget()
    if Toast.widget and Toast.widget:IsValid() then return Toast.widget end

    local layout = Layout()
    if not layout then return nil end

    local root
    pcall(function() root = layout.WidgetTree.RootWidget end)
    if not root or not root:IsValid() then return nil end

    local cls = StaticFindObject("/Script/UMG.TextBlock")
    if not cls then return nil end

    local tb, slot
    local ok = pcall(function()
        tb   = StaticConstructObject(cls, layout)
        slot = root:AddChild(tb)
    end)
    if not ok or not tb or not tb:IsValid() then return nil end

    pcall(function() tb:SetShadowOffset({ X = 2.0, Y = 2.0 }) end)
    pcall(function() tb:SetShadowColorAndOpacity({ R = 0.0, G = 0.0, B = 0.0, A = 1.0 }) end)
    pcall(function()
        tb:SetColorAndOpacity({ SpecifiedColor = { R = 1.0, G = 0.86, B = 0.30, A = 1.0 },
                                ColorUseRule = 0 })
    end)
    if slot and slot:IsValid() then
        pcall(function() slot:SetAutoSize(true) end)
        pcall(function() slot:SetPosition({ X = cfg.message_x + 0.0, Y = cfg.message_y + 0.0 }) end)
    end

    Toast.widget = tb
    return tb
end

local function Say(msg)
    print("[NoDayCost] " .. msg .. "\n")
    local tb = ToastWidget()
    if not tb then return end
    pcall(function()
        tb:SetText(FText(msg))
        tb:SetVisibility(0)
    end)
    Toast.token = Toast.token + 1
    local mine = Toast.token
    ExecuteWithDelay(cfg.message_seconds * 1000, function()
        ExecuteInGameThread(function()
            if Toast.token == mine and Toast.widget and Toast.widget:IsValid() then
                pcall(function() Toast.widget:SetVisibility(1) end)
            end
        end)
    end)
end

local function Lock()
    local m = TurnMgr()
    if not m then Say("Time lock unavailable right now") return end
    pcall(function() m:AddTurnBlockingKey(BLOCK_KEY) end)
    if IsLocked() then Say("Time stopped - missions will not cost a day")
    else Say("Time lock failed") end
end

local function Unlock(quiet)
    local m = TurnMgr()
    if not m then return end
    pcall(function() m:RemoveTurnBlockingKey(BLOCK_KEY) end)
    if not quiet then Say("Time flows normally - missions cost a day") end
end

local kToggle = Key4(cfg.keys.toggle_time_lock)
if kToggle then
    RegisterKeyBind(kToggle, function()
        ExecuteInGameThread(function()
            if IsLocked() then Unlock() else Lock() end
        end)
    end)
end

local kClear = Key4(cfg.keys.clear_blocks)
if kClear then
    RegisterKeyBind(kClear, function()
        ExecuteInGameThread(function()
            local m = TurnMgr()
            if not m then Say("Turn manager unavailable") return end
            pcall(function() m:DebugClearTurnBlockingKeys() end)
            Say("All turn blocks cleared")
        end)
    end)
end

local kAdvance = Key4(cfg.keys.advance_day)
if kAdvance then
    RegisterKeyBind(kAdvance, function()
        ExecuteInGameThread(function()
            if ActiveState() ~= DEN_STATE then
                Say("Advance day works only in the Den")
                return
            end
            Unlock(true)
            local m = TurnMgr()
            if m then
                local ok, can = pcall(function() return m:CanAdvanceStrategyTurn() end)
                if ok and can == false then
                    Say("Turn is blocked by the game - cannot advance")
                    return
                end
            end
            local st, sm = FindState(ENDTURN)
            if not st or not sm or not sm:IsValid() then
                Say("Cannot reach the end of turn")
                return
            end
            local ok = pcall(function() sm:SwitchActiveState(st, true) end)
            Say(ok and "Advancing to the next day" or "Could not advance the day")
        end)
    end)
end

if cfg.enable_force_win then
    local kWin = Key4(cfg.keys.force_win)
    if kWin then
        RegisterKeyBind(kWin, function()
            ExecuteInGameThread(function()
                local st, sm = FindState(WIN_STATE)
                if not st or not sm or not sm:IsValid() then
                    Say("Not in a mission")
                    return
                end
                local ok = pcall(function() sm:SwitchActiveState(st, true) end)
                if not ok then Say("Could not complete the mission") end
            end)
        end)
    end
end

if cfg.auto_unlock_in_den then
    local path = "/Game/Game/GameData/Logic/GameplayMaster/GameplayMasterStates/"
              .. "GMState_Headquarters_ExplorePhase.GMState_Headquarters_ExplorePhase_C:OnStateBegin"
    local function arm(attempt)
        local ok = pcall(function()
            RegisterHook(path, function()
                if IsLocked() then Unlock(true) end
            end)
        end)
        if not ok and attempt < 30 then
            ExecuteWithDelay(10000, function()
                ExecuteInGameThread(function() arm(attempt + 1) end)
            end)
        end
    end
    arm(1)
end

print(string.format("[NoDayCost] ready - %s time lock, %s advance day, %s clear blocks%s\n",
    cfg.keys.toggle_time_lock, cfg.keys.advance_day, cfg.keys.clear_blocks,
    cfg.enable_force_win and (", " .. cfg.keys.force_win .. " finish mission") or ""))
