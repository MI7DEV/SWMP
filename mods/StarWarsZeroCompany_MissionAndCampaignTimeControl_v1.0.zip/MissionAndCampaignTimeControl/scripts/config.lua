return {
    keys = {
        toggle_time_lock = "F4", -- key for time flow control
        advance_day      = "F2", -- key for advancing a day
        force_win        = "F8", -- finished mission with a win
        clear_blocks     = "F3", -- debug command to reset the system when you are trying to do something unexpected
    },

    auto_unlock_in_den = true, 
    enable_force_win   = true, -- change to false if you don't want mission "winner" function

    message_seconds = 4,
    message_x       = 80,
    message_y       = 40,
}
