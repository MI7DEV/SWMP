START WITH REX AND ANAKIN
v2.0 - Star Wars Zero Company


WHAT IT DOES

Replaces two of your starting squad members with Captain Rex and Anakin
Skywalker. Both are fully finished characters that ship inside the game but
which the campaign never lets you recruit.

  Kabb Uppercut  ->  Captain Rex
  Trick          ->  Anakin Skywalker

They are not reskins. Each arrives with their own class, name, portrait and
signature gear - Rex as his own Rex class with the DC-17 blaster pistol, Anakin
as a Jedi Knight with Anakin's Lightsaber, and both with their own working
specialisation trees.

Rex also has his talent enabled: For My Brothers.

Your own created character is untouched, as is the squadmate who dies during the
tutorial. Squad size, mission rewards and story progression are all unchanged -
you play exactly the campaign the game intends, with two famous faces in it.


INSTALL

1. Find your game folder. On Steam: right-click the game, Manage, Browse local
   files.
2. Go to  SWZeroCompany\Content\Paks\
3. Create a folder called  ~mods  if it is not already there. The tilde matters.
4. Copy all three files into it:
      StartingSquadLegends_P.pak
      StartingSquadLegends_P.ucas
      StartingSquadLegends_P.utoc

To uninstall, delete those three files.


IMPORTANT - START A NEW CAMPAIGN

The starting squad is written into your save when a campaign is created, so this
will not change a campaign already in progress.


IMPORTANT - TURN OFF "PLAY TUTORIAL MISSION"

On the difficulty screen when starting a new campaign you will find a setting
called "Play Tutorial Mission". Turn it OFF. You only need to do this once - the
choice is remembered.

The tutorial places your squad at scripted positions written for the original
characters. With different characters in those slots one squadmate is dropped in
the wrong place, sometimes at the edge of the map, and can be unable to reach a
scripted move point - which can leave you stuck.

Skipping costs you nothing. The only squadmate you lose by skipping is the one
the tutorial kills anyway, so either way you continue with your own character
plus Rex and Anakin.

That setting is genuine unused developer content. It is complete and fully
written, including its own confirmation prompt, but was never attached to any
menu. This mod puts it on the difficulty screen in place of the "Show Tutorials"
toggle, which only controls tutorial popups.


KNOWN LIMITATION

Anakin's talent line reads "None". Talents live in a slot his character
definition does not contain, and adding one was not solved. His specialisation
tree, abilities, gear and everything else work normally - only the single talent
perk track is empty.


COMPATIBILITY

No script extender or mod manager needed. Conflicts with any other mod that
edits Campaign_MainStory, the difficulty settings list, or Captain Rex's
character definition.

Built against the retail PC build. Steam updates that change the campaign data
may require a rebuild.
