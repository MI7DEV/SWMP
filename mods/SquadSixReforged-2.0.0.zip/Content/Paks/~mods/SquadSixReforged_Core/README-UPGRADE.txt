Squad Six Reforged v2.0.0

Gameplay is pak-only and does not require UE4SS. The internal plugin path remains
SquadSixGF; that is intentional and does not affect the player-facing name. Keep all three container files.

UPGRADING FROM v1
1. Close the game. If upgrading from v1, keep it installed until replacement.
2. Remove the manually installed SquadSixGF_P.pak/.ucas/.utoc trial files from
   Content/Paks/~mods/ before installing this ZIP. Do not load both copies.
3. Import this ZIP, use the manager's Replace/Update option and deploy it.
4. Check that the old Core entry was replaced, not left alongside another pak.
5. Check the runtime folder at Binaries/Win64/ue4ss/Mods/SquadSixReforged/.
   For this compatibility ZIP, the runtime contains a harmless Scripts/main.lua
   stub plus zcom-mod.json and modinfo.json preserving its upgrade identity. Install BOTH components when offered. ZMM was confirmed to
   remove the old modules on replacement. Other managers may leave unused files.
6. Restart the game and check squad select, holotable range and deployment.
7. When uninstalling, use the manager that deployed the files.

MANUAL INSTALL
Archive paths start inside SWZeroCompany/. Extract into SWZeroCompany/, allowing
replacement of the old Core containers. Clean edition: remove the v1 UE4SS mod
folder. Compatibility edition: overwrite its Scripts/main.lua with the stub.
Do not change UE4SS itself, mods.txt, other mods or player settings.

EXPECTED LIMITS
Zero Mod Manager source detects replacement by matching container source names
and UE4SS folder names. Keeping these names offers each v1 component as an
upgrade candidate. Upgrade matching was tested in Zero Mod Manager and Mod Command.
Vortex upgrade cleanup has not been verified. Choose update or
replace rather than installing a second independent copy. File-conflict rules
must let v2 win. The compatibility ZIP does not erase files or disable an older
mod that a manager redeploys later. Its Lua stubs are optional upgrade aids,
not a dependency. No fake or empty Unreal containers are included.
