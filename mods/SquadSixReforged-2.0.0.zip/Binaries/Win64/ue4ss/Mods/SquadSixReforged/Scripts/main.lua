-- Squad Six Reforged v2 upgrade compatibility: retired v1 module.
-- Gameplay now runs in the Game Feature pak; no hooks or timers are registered here.
return {}
