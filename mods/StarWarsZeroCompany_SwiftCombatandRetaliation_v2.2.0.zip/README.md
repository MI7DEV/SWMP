# 星球大战：零号连队 MOD — 战斗与反击加速

英文名：**Swift Combat and Retaliation** · 版本：**2.2.0**

一份 UE4SS Lua 包，把玩家出手、助攻镜头、敌方回合、以及我方反击／警戒射击的**演出间隔**压到大约 1 秒。上一段动画按原速播完，下一段提前开始（重叠，而不是把 2 秒动作压成 0.5 秒）。

需要游戏专用 **UE4SS**（不随本包附带）。请**不要**再同时启用旧的 `SwiftActions` / `SwiftAssistShots` / `SwiftEnemyTurn`，本包已经合并这三项。

Nexus 上的 **Swift Enemy Turn** 1.0.0 是早期只加速敌方回合的版本。请改用本包：文件夹名是 `SwiftCombat`，并关掉 `SwiftEnemyTurn`。

## 功能

- **敌方回合约 1 秒一拍**：多名敌人不再等完整 cinematic 才轮到下一个。
- **动画原速重叠**：默认不跳过枪口／激光；不把行走压成滑步。移动技能不会被 skip。
- **账本同步（2.2）**：1 秒只是检查点。账上还有**还没开演**的镜头（多人受击、火箭装下一发、未请求的反击）时，导演不会 `TimedOut`。已经在播的，导演和引擎同一拍切到下一个目标，上一枪继续演。
- **我方反击／警戒在活节点上演出**：不再为了给空垫拍腾位置而 0.2 秒切走当前拍。
- **WaitForStory 走原生**：不再提前 `TimeoutOccured`（那是手雷 / AoE HUD 卡死的根因之一）。
- **助攻镜头缩短**：助攻窗口内同样缩短盯人等待。
- **玩家主动 Skip 默认关闭**：`CanSkip` 会把剩余蒙太奇压进短窗口，看起来像漂移。
- **可调**：全部时序在 `config.ini`。

不改伤害、AI 决策或存档，只动演出时序。

## 2.2 修了什么

相对冻结的 2.0 完美版，以及 Nexus 上 Swift Enemy Turn 1.0.0 的反馈：

| 问题 | 原因 | 2.2 |
|---|---|---|
| 单体开枪后空等约 5–10 秒 | 导演已经 `TimedOut`，引擎还在等过场结束才允许下一拍 | 同一帧放行 TurnCoordinator（`IsReadyForPresentation` / `FinishedAllFires`），不掐蒙太奇 |
| B2 火箭打完立刻装下一发软锁 | 导演提前结束，后续演出还没请求 | 账上有未开演的就不 `TimedOut` |
| Shared Suffering / 手雷 AoE 软锁 | `WaitForStory` 被 `TimeoutOccured` 提前结束 | WaitForStory 完全原生 |
| 火箭炸多人后反击链卡死 | 第一次反击 0.2 秒就切节点 | 反击在当前活节点请求演出 |
| SET 1.0 反击约 60/40 不触发 | 没有 BusHold / Out 表请求 | 2.0 起已有；2.2 改为同节点接着演 |
| 按火箭/AoE 名单打补丁仍卡 | 名单漏了一样会卡 | 不再按技能名白名单，只看「正在播 / 还没开始」 |

2.0 相对 1.0：修好了多人连环反击时最后一发激活后导演空等的问题。

## 安装

1. 已安装 [UE4SS for Star Wars Zero Company](https://www.nexusmods.com/starwarszerocompany/mods)。
2. 关闭游戏。
3. 将 **`SwiftCombat`** 整个文件夹复制到：

   `SWZeroCompany\Binaries\Win64\ue4ss\Mods\`

4. 编辑 `ue4ss\Mods\mods.txt`，在 `Keybinds : 1` **之上**增加一行：

   `SwiftCombat : 1`

5. 若仍留着 `SwiftActions` / `SwiftAssistShots` / `SwiftEnemyTurn`，把对应行改成 `: 0` 或删掉。
6. 启动游戏。`UE4SS.log` 应出现 `Starting Lua mod 'SwiftCombat'` 以及 `LOAD version=2.2 build=2.2-status-sync`。

## 卸载

删除 `ue4ss\Mods\SwiftCombat`，并从 `mods.txt` 去掉对应行。

## 调节

编辑 `SwiftCombat\config.ini`：

| 段 | 项 | 默认 | 作用 |
|---|---|---|---|
| General | Enabled | true | 总开关 |
| Actions | Enabled | false | 玩家主动 Skip（易把走路压成漂移，默认关） |
| Actions | SafetyDelay | 1.00 | Skip 前最少演出时间 |
| EnemyTurn | SimultaneousTimeout | 1.00 | Lua 检查点间隔（不是「动画播完」） |
| EnemyTurn | WatchUnitDelay | 1.00 | 盯人等待 |
| EnemyTurn | SkipCineBeats | false | true 时跳过敌方电影机位 |
| AssistShots | AssistDelay | 1.00 | 助攻窗口盯人等待 |
| PlayerCounter | CounterChain | 1.00 | 反击演完后本节点额外停留 |
| PlayerCounter | BusHold | 4.00 | 反击窗口内空节点最多停留，等其他单位开火 |
| PlayerCounter | SkipCineBeats | false | true 时跳过反击 cine beat（枪火可能看不见） |

`WaitForStoryTimeout` / `UnblockDelay` 仍写在 ini 里，2.2 不再用它们提前结束演出。

## 兼容性

- 游戏：*Star Wars: Zero Company*
- 依赖：该游戏专用 UE4SS 兼容构建
- 替代 SwiftActions、SwiftAssistShots、SwiftEnemyTurn，请勿与它们同时加载

## 许可证

仅供个人与社区非商业使用；游戏资产归相应权利方所有。
