## Swift Combat and Retaliation v2.2.0

UE4SS pack: enemy attacks, assist cameras, and player retaliation / overwatch on about a **one-second beat**. Previous montages keep playing at normal speed (overlap).

Replaces **SwiftActions**, **SwiftAssistShots**, and **SwiftEnemyTurn**. Folder name is `SwiftCombat`. In-game log: `LOAD version=2.2 build=2.2-status-sync`.

### 2.2
- 1s is a ledger checkpoint, not an animation cut
- Unstarted presentations (AoE hit-reacts, rocket arm-next, pending counters) block director `TimedOut`
- Already-playing shots: director and TurnCoordinator switch focus on the same beat; cine is not `SequenceDone`
- Counters request presentation on the live node (no 0.2s UnblockDelay cut)
- `WaitForStory` never `TimeoutOccured`
- No per-skill AoE whitelist

### Install
1. Close the game
2. Copy `SwiftCombat` into `SWZeroCompany\Binaries\Win64\ue4ss\Mods\`
3. In `mods.txt`, above `Keybinds : 1`, add: `SwiftCombat : 1`
4. Disable SwiftActions / SwiftAssistShots / SwiftEnemyTurn if those folders are still present

Chinese readme: `README.md` in the archive.
