-- 加速战斗 2.2 — from 2.0 perfect baseline（导演/引擎账本同步）
-- 冻结 2.0: ue4ss/modsbackup/SwiftCombat-2.0（勿覆盖）
-- 1 秒只是检查点。有未开演的镜头就不 TimedOut。已在播的靠
-- bUnrestrictPlayingAnimations 继续演，导演和引擎同一拍切下一目标。
-- 不按技能白名单；不对 cine 发 SequenceDone；WaitForStory 不 TimeoutOccured。
local MOD_NAME = "SwiftCombat"
local MOD_VERSION = "2.2"
local BUILD_ID = "2.2-status-sync"

local DEFAULT_ACTION_ENABLED = true
local ACTION_TIMEOUT_SECONDS = 1.0
local ASSIST_WINDOW_SECONDS = 3.0
local COUNTER_WINDOW_SECONDS = 8.0
local ENEMY_TURN_WINDOW_SECONDS = 8.0

local TARGETING_COMPLETED_PATH =
    "/Game/Game/GameData/Abilities/Typical/GA_Typical_SingleTarget.GA_Typical_SingleTarget_C:TargetingCompleted"
local CAN_SKIP_PATH =
    "/Game/Game/GameData/Logic/GameplayMaster/GameplayMasterStates/GMState_CommitAndPresentPlan.GMState_CommitAndPresentPlan_C:CanSkipAbilityPresentation"
local COMMIT_END_PATH =
    "/Game/Game/GameData/Logic/GameplayMaster/GameplayMasterStates/GMState_CommitAndPresentPlan.GMState_CommitAndPresentPlan_C:OnStateEnd"
local PRESENTATION_REQUEST_PATH =
    "/Game/Game/Core/Blueprints/BP_AbilitySequenceManager.BP_AbilitySequenceManager_C:TurnDirectorRequestAbilityPresentation"
local CHOREOGRAPHED_ROOT =
    "/Game/Game/Cinematics/Blueprints/Stage/StateMachine/SMstate_PlayChoreographedSequence.SMstate_PlayChoreographedSequence_C:"
local VIEW_TARGET_DELAY_ROOT =
    "/Game/Game/Cinematics/Blueprints/Stage/StateMachine/SMstate_DelayUntilViewTargetTagsMatch.SMstate_DelayUntilViewTargetTagsMatch_C:"
local RUN_BY_PLAN_BEGIN =
    "/Game/Game/Cinematics/Blueprints/TurnDirectorStateMachines/States/SMState_EnemyTurnStoryNode_RunAbilitiesByPlanIndex.SMState_EnemyTurnStoryNode_RunAbilitiesByPlanIndex_C:OnStateBegin"
local SIMULTANEOUS_BEGIN =
    "/Game/Game/Cinematics/Blueprints/TurnDirectorStateMachines/States/SMState_EnemyTurnStoryNode_StartAbilitiesSimultaneously.SMState_EnemyTurnStoryNode_StartAbilitiesSimultaneously_C:OnStateBegin"
local SIMULTANEOUS_UPDATE =
    "/Game/Game/Cinematics/Blueprints/TurnDirectorStateMachines/States/SMState_EnemyTurnStoryNode_StartAbilitiesSimultaneously.SMState_EnemyTurnStoryNode_StartAbilitiesSimultaneously_C:OnStateUpdate"
local WAIT_STORY_BEGIN =
    "/Game/Game/Core/Prototypes/EnemyTurn/Sequences/Nodes/SMState_WaitForStoryAbilitiesToFinish.SMState_WaitForStoryAbilitiesToFinish_C:OnStateBegin"
local WAIT_STORY_UPDATE =
    "/Game/Game/Core/Prototypes/EnemyTurn/Sequences/Nodes/SMState_WaitForStoryAbilitiesToFinish.SMState_WaitForStoryAbilitiesToFinish_C:OnStateUpdate"
local WAIT_STORY_IS_FINISHED =
    "/Game/Game/Core/Prototypes/EnemyTurn/Sequences/Nodes/SMState_WaitForStoryAbilitiesToFinish.SMState_WaitForStoryAbilitiesToFinish_C:IsPresentationFinished"
local ABILITY_COMMITTED =
    "/Game/Game/Core/Blueprints/BP_AbilitySequenceManager.BP_AbilitySequenceManager_C:OnAbilityCommitted"
local SHOULD_PLAY_CINE =
    "/Game/Game/Core/Blueprints/BP_AbilitySequenceManager.BP_AbilitySequenceManager_C:ShouldPlayExecutionCineBeat"
local IS_PLAYER_TURN =
    "/Game/Game/Core/Blueprints/BP_AbilitySequenceManager.BP_AbilitySequenceManager_C:IsPlayerTurn"

local ASSIST_ACTIVATE_PATHS = {
    "/Game/Game/GameData/Abilities/GA_Backup_TeamworkAssistShot.GA_Backup_TeamworkAssistShot_C:K2_ActivateAbilityFromEvent",
    "/Game/Game/GameData/Abilities/Common/GA_TeamworkAssistShot.GA_TeamworkAssistShot_C:K2_ActivateAbilityFromEvent",
}

local COUNTER_ACTIVATE_PATHS = {
    "/Game/Game/GameData/Abilities/Counters/Retaliate/GA_RetaliationShot_Heavy_NEW.GA_RetaliationShot_Heavy_NEW_C:K2_ActivateAbilityFromEvent",
    "/Game/Game/GameData/Abilities/Counters/Retaliate/GA_RetaliationShot_Base.GA_RetaliationShot_Base_C:K2_ActivateAbilityFromEvent",
    "/Game/Game/GameData/Abilities/Counters/Retaliate/GA_RetaliationForcePush.GA_RetaliationForcePush_C:K2_ActivateAbilityFromEvent",
    "/Game/Game/GameData/Abilities/Counters/Overwatch/GA_OverwatchActive_AttackTrigger_Base.GA_OverwatchActive_AttackTrigger_Base_C:K2_ActivateAbilityFromEvent",
    "/Game/Game/GameData/Abilities/Counters/Overwatch/GA_OverwatchActive_MoveTrigger_Base.GA_OverwatchActive_MoveTrigger_Base_C:K2_ActivateAbilityFromEvent",
    "/Game/Game/GameData/Abilities/Counters/OverwatchMelee/GA_OverwatchMeleeActive_MoveTrigger_Base.GA_OverwatchMeleeActive_MoveTrigger_Base_C:K2_ActivateAbilityFromEvent",
    "/Game/Game/GameData/Abilities/Counters/OverwatchMelee/GA_OverwatchMelee_Base.GA_OverwatchMelee_Base_C:K2_ActivateAbilityFromEvent",
    "/Game/Game/GameData/Abilities/Counters/Overwatch/GA_Overwatch_Rifle.GA_Overwatch_Rifle_C:K2_ActivateAbilityFromEvent",
    "/Game/Game/GameData/Abilities/Counters/Overwatch/GA_Overwatch_Pistol.GA_Overwatch_Pistol_C:K2_ActivateAbilityFromEvent",
    "/Game/Game/GameData/Abilities/Counters/Overwatch/GA_Overwatch_Pistol_Rex.GA_Overwatch_Pistol_Rex_C:K2_ActivateAbilityFromEvent",
    "/Game/Game/GameData/Abilities/Counters/Overwatch/GA_Overwatch_DC17m.GA_Overwatch_DC17m_C:K2_ActivateAbilityFromEvent",
    "/Game/Game/GameData/Abilities/Counters/Overwatch/GA_Overwatch_Longarm.GA_Overwatch_Longarm_C:K2_ActivateAbilityFromEvent",
    "/Game/Game/GameData/Abilities/Counters/Overwatch/GA_Overwatch_Repeater.GA_Overwatch_Repeater_C:K2_ActivateAbilityFromEvent",
    "/Game/Game/GameData/Abilities/Counters/Overwatch/GA_Overwatch_New_Conical.GA_Overwatch_New_Conical_C:K2_ActivateAbilityFromEvent",
}

local registered_hooks = {}
local config = {
    enabled = true,
    actions_enabled = true,
    safety_delay = 0.50,
    actions = {},
    enemy_enabled = true,
    watch_unit_delay = 1.00,
    wait_for_story_timeout = 1.00,
    simultaneous_timeout = 1.00,
    skip_cine_beats = false,
    keep_playing = true,
    assist_enabled = true,
    assist_delay = 1.00,
    counter_enabled = true,
    counter_watch_delay = 1.00,
    counter_safety_delay = 1.00,
    counter_skip_cine = false,
    counter_keep_playing = true,
    counter_unblock_delay = 0.20,
    counter_grace = 0.00,
    -- Extra hold after a counter presentation so a follow-up shot
    -- (~1.8s later) can still activate on this live node.
    counter_chain = 1.00,
    -- Empty node bus while another unit may still retaliate.
    counter_bus_hold = 4.00,
    path = "not found",
}

local active_action = nil
local active_ability_label = nil
local active_until = 0.0
local active_runner_hint = nil
local active_presentation_requested = false
local active_presentation_state_started = false
local skip_delay_until = 0.0
local wait_logged = false
local delay_logged = false
local force_logged = false

local enemy_turn_until = 0.0
local assist_window_until = 0.0
local counter_window_until = 0.0
local wait_story_started_at = 0.0
local hook_fail_logged = {}
local last_counter_at = 0.0
local last_presentation_at = 0.0
local last_presentation_was_counter = false
local pending_unpresented_counter = false
local sim_started_at = 0.0
local sim_unblocked = false
local last_sim_state = nil
local last_sim_begin_at = 0.0
local last_wait_story_state = nil
local last_seq = nil
local last_runner = nil
local pending_counter_ability = nil
local presentation_request_tried = false
local sim_token = 0
local last_wait_unstarted_log = 0.0
local last_unstarted_schedule_at = 0.0
local last_objects_n = -1
local last_objects_change_at = 0.0
local status_probe_logged = false
local schedule_sim_advance
local try_advance_sim
local try_request_counter_presentation
local refresh_sim_timeout
-- Intra-turn stalls of 6–14s were logged as a new wave and cleared a
-- still-waiting counter. Real turn gaps are much longer.
local WAVE_RESET_GAP = 25.0

local function log(message)
    print(string.format("[%s %.3f] %s\n", MOD_NAME, os.clock(), message))
end

local function unwrap(value)
    if not value then
        return nil
    end

    local ok, unwrapped = pcall(function()
        return value:get()
    end)

    if ok and unwrapped then
        return unwrapped
    end

    return value
end

local function is_valid_object(value)
    local object = unwrap(value)
    if not object then
        return false
    end

    local ok, valid = pcall(function()
        return object:IsValid()
    end)

    return ok and valid == true
end

local function object_label(value)
    local object = unwrap(value)
    if not object then
        return "nil"
    end

    local ok, full_name = pcall(function()
        return object:GetFullName()
    end)

    if ok and full_name ~= nil then
        return tostring(full_name)
    end

    return tostring(object)
end

local function trim(value)
    return (value or ""):gsub("^%s+", ""):gsub("%s+$", "")
end

local function normalize_name(name)
    return string.lower(name or ""):gsub("[%s_%-]", "")
end

local function parse_bool(value)
    local lower = string.lower(trim(value))
    if lower == "true" or lower == "1" or lower == "yes" or lower == "on" then
        return true
    end
    if lower == "false" or lower == "0" or lower == "no" or lower == "off" then
        return false
    end
    return nil
end

local function config_path()
    local ok, directories = pcall(IterateGameDirectories)
    local win64 = ok and directories and directories.Game
        and directories.Game.Binaries and directories.Game.Binaries.Win64

    if not win64 then
        return nil
    end

    return win64.__absolute_path .. "\\ue4ss\\Mods\\" .. MOD_NAME .. "\\config.ini"
end

local function load_config()
    local path = config_path()
    if not path then
        log("CONFIG unavailable; using defaults")
        return
    end

    config.path = path
    local file = io.open(path, "r")
    if not file then
        log("CONFIG missing; using defaults path=" .. path)
        return
    end

    local section = "general"
    for raw_line in file:lines() do
        local line = trim(raw_line:gsub("[;#].*$", ""))
        local section_name = line:match("^%[(.-)%]$")
        if section_name then
            section = string.lower(trim(section_name))
        else
            local key, value = line:match("^([^=]+)=(.*)$")
            if key and value then
                key = trim(key)
                value = trim(value)
                local lower_key = string.lower(key)

                if section == "general" and lower_key == "enabled" then
                    local parsed = parse_bool(value)
                    if parsed ~= nil then
                        config.enabled = parsed
                    end
                elseif section == "actions" and lower_key == "enabled" then
                    local parsed = parse_bool(value)
                    if parsed ~= nil then
                        config.actions_enabled = parsed
                    end
                elseif section == "actions" and lower_key == "safetydelay" then
                    local parsed = tonumber(value)
                    if parsed and parsed >= 0 then
                        config.safety_delay = parsed
                    end
                elseif section == "actions" then
                    local parsed = parse_bool(value)
                    if parsed ~= nil then
                        config.actions[normalize_name(key)] = parsed
                    end
                elseif section == "enemyturn" and lower_key == "enabled" then
                    local parsed = parse_bool(value)
                    if parsed ~= nil then
                        config.enemy_enabled = parsed
                    end
                elseif section == "enemyturn" and lower_key == "watchunitdelay" then
                    local parsed = tonumber(value)
                    if parsed and parsed >= 0 then
                        config.watch_unit_delay = parsed
                    end
                elseif section == "enemyturn" and lower_key == "waitforstorytimeout" then
                    local parsed = tonumber(value)
                    if parsed and parsed >= 0 then
                        config.wait_for_story_timeout = parsed
                    end
                elseif section == "enemyturn" and lower_key == "simultaneoustimeout" then
                    local parsed = tonumber(value)
                    if parsed and parsed >= 0 then
                        config.simultaneous_timeout = parsed
                    end
                elseif section == "enemyturn" and lower_key == "skipcinebeats" then
                    local parsed = parse_bool(value)
                    if parsed ~= nil then
                        config.skip_cine_beats = parsed
                    end
                elseif section == "enemyturn" and lower_key == "keepplayingonstateend" then
                    local parsed = parse_bool(value)
                    if parsed ~= nil then
                        config.keep_playing = parsed
                    end
                elseif section == "assistshots" and lower_key == "enabled" then
                    local parsed = parse_bool(value)
                    if parsed ~= nil then
                        config.assist_enabled = parsed
                    end
                elseif section == "assistshots" and lower_key == "assistdelay" then
                    local parsed = tonumber(value)
                    if parsed and parsed >= 0 then
                        config.assist_delay = parsed
                    end
                elseif section == "playercounter" and lower_key == "enabled" then
                    local parsed = parse_bool(value)
                    if parsed ~= nil then
                        config.counter_enabled = parsed
                    end
                elseif section == "playercounter" and lower_key == "watchunitdelay" then
                    local parsed = tonumber(value)
                    if parsed and parsed >= 0 then
                        config.counter_watch_delay = parsed
                    end
                elseif section == "playercounter" and lower_key == "safetydelay" then
                    local parsed = tonumber(value)
                    if parsed and parsed >= 0 then
                        config.counter_safety_delay = parsed
                    end
                elseif section == "playercounter" and lower_key == "skipcinebeats" then
                    local parsed = parse_bool(value)
                    if parsed ~= nil then
                        config.counter_skip_cine = parsed
                    end
                elseif section == "playercounter" and lower_key == "keepplayingonstateend" then
                    local parsed = parse_bool(value)
                    if parsed ~= nil then
                        config.counter_keep_playing = parsed
                    end
                elseif section == "playercounter" and lower_key == "unblockdelay" then
                    local parsed = tonumber(value)
                    if parsed and parsed >= 0 then
                        config.counter_unblock_delay = parsed
                    end
                elseif section == "playercounter" and lower_key == "countergrace" then
                    local parsed = tonumber(value)
                    if parsed and parsed >= 0 then
                        config.counter_grace = parsed
                    end
                elseif section == "playercounter" and lower_key == "counterchain" then
                    local parsed = tonumber(value)
                    if parsed and parsed >= 0 then
                        config.counter_chain = parsed
                    end
                elseif section == "playercounter" and lower_key == "bushold" then
                    local parsed = tonumber(value)
                    if parsed and parsed >= 0 then
                        config.counter_bus_hold = parsed
                    end
                end
            end
        end
    end

    file:close()
    log("CONFIG loaded path=" .. config.path)
end

local function name_from_full_label(label)
    local short_name = tostring(label or ""):match("([^%.]+)$")
    if not short_name then
        return nil
    end

    return short_name:gsub("_C_%d+$", ""):gsub("_C$", "")
end

local function friendly_name(name)
    if not name then
        return nil
    end

    return trim(name
        :gsub("^GA_", "")
        :gsub("_C_%d+$", "")
        :gsub("_C$", "")
        :gsub("_", " ")
        :gsub("(%l)(%u)", "%1 %2"))
end

local function base_friendly_name(name)
    if not name then
        return nil
    end

    return trim(name:gsub("%s+T%d+$", ""))
end

local function describe_ability(value)
    local ability = unwrap(value)
    if not is_valid_object(ability) then
        return nil, nil, nil, object_label(value)
    end

    local label = object_label(ability)
    local token = name_from_full_label(label)
    local friendly = friendly_name(token)
    return token, friendly, base_friendly_name(friendly), label
end

local function is_move_ability(label, friendly, base_friendly)
    local n = string.lower(tostring(label or "") .. " " .. tostring(friendly or "") .. " " .. tostring(base_friendly or ""))
    return n:find("standardmove", 1, true)
        or n:find("cloakablemove", 1, true)
        or n:find("freemove", 1, true)
        or n:find("ga_move", 1, true)
        or n:find("movewiththeforce", 1, true)
        or n:find("reactionmove", 1, true)
end

local function is_counter_ability(label)
    local n = string.lower(tostring(label or ""))
    if n:find("generate_retaliation", 1, true) then
        return false
    end

    return n:find("retaliationshot", 1, true)
        or n:find("retaliationforce", 1, true)
        or n:find("overwatchactive", 1, true)
        or n:find("overwatchmelee", 1, true)
        or n:find("ga_overwatch_", 1, true)
        or n:find("ga_retaliation", 1, true)
end

local function pack_on()
    return config.enabled == true
end

local function in_enemy_turn()
    return os.clock() < enemy_turn_until
end

local function in_assist_window()
    return config.assist_enabled and os.clock() < assist_window_until
end

local function in_counter_window()
    return config.counter_enabled and os.clock() < counter_window_until
end

local function mark_enemy_turn()
    enemy_turn_until = os.clock() + ENEMY_TURN_WINDOW_SECONDS
end

local function arm_assist_window()
    if not pack_on() or not config.assist_enabled then
        return
    end

    assist_window_until = os.clock() + ASSIST_WINDOW_SECONDS
    log("ASSIST window armed")
end

local function arm_counter_window(reason, ability)
    if not pack_on() or not config.counter_enabled then
        return
    end

    -- Commit/activate often fire again on the same frame as presentation.
    -- Re-arming pending there would TimedOut the new node after 0.2s.
    if last_presentation_was_counter
        and (os.clock() - last_presentation_at) < 0.25 then
        return
    end

    counter_window_until = os.clock() + COUNTER_WINDOW_SECONDS
    last_counter_at = os.clock()
    pending_unpresented_counter = true
    if ability then
        local next_ability = unwrap(ability) or ability
        if pending_counter_ability ~= next_ability then
            presentation_request_tried = false
        end
        pending_counter_ability = next_ability
    end
    log("COUNTER window armed reason=" .. tostring(reason)
        .. " unblocked=" .. tostring(sim_unblocked))
    -- Present on this still-live node. Do not UnblockDelay-cut so the next
    -- empty pad can play it: that ends the beat before AoE hit-reacts and
    -- later retaliations can request presentation.
    if try_request_counter_presentation then
        try_request_counter_presentation()
    end
end

local function action_enabled(friendly, base_friendly)
    if not pack_on() or not config.actions_enabled then
        return false, "actions-disabled"
    end

    for _, candidate in ipairs({ friendly, base_friendly }) do
        if candidate then
            local key = normalize_name(candidate)
            local override = config.actions[key]
            if override ~= nil then
                return override, candidate .. " (key=" .. key .. ")"
            end
        end
    end

    return DEFAULT_ACTION_ENABLED, "default=" .. tostring(DEFAULT_ACTION_ENABLED)
end

local function clear_active_action()
    active_action = nil
    active_ability_label = nil
    active_until = 0.0
    active_runner_hint = nil
    active_presentation_requested = false
    active_presentation_state_started = false
    skip_delay_until = 0.0
    wait_logged = false
    delay_logged = false
    force_logged = false
end

local function active_action_valid()
    if not active_action then
        return false
    end

    if os.clock() > active_until then
        clear_active_action()
        return false
    end

    return true
end

local function runner_hint(value)
    return object_label(value):match("BitReactorCinematicSMRunner_%d+")
end

local function maybe_arm_delay()
    if not active_action
        or not active_presentation_requested
        or not active_presentation_state_started
        or skip_delay_until > 0.0 then
        return
    end

    local delay = config.safety_delay
    if in_counter_window() then
        delay = config.counter_safety_delay
    end

    skip_delay_until = os.clock() + delay
    log("ACTION ready action=" .. tostring(active_action)
        .. " safety_delay=" .. tostring(delay))
end

local function arm_action(context)
    local token, friendly, base_friendly, label = describe_ability(context)
    if is_counter_ability(label) then
        arm_counter_window(label)
    end

    local enabled, source = action_enabled(friendly, base_friendly)
    if is_move_ability(label, friendly, base_friendly) then
        enabled, source = false, "move-no-skip"
    end
    log("ACTION decision token=" .. tostring(token)
        .. " friendly=" .. tostring(friendly)
        .. " enabled=" .. tostring(enabled)
        .. " source=" .. source)

    clear_active_action()
    if not enabled then
        return
    end

    active_action = friendly or token or label
    active_ability_label = label
    active_until = os.clock() + ACTION_TIMEOUT_SECONDS
end

local function apply_can_skip(can_skip_param, phase)
    -- Retaliation/overwatch must actually present. CanSkip during the counter
    -- window was skipping that presentation, then playing it on the next
    -- voluntary player attack.
    if in_counter_window() or active_action == "PlayerCounter" then
        return
    end

    if is_move_ability(active_ability_label, active_action, nil) then
        return
    end

    if not active_action_valid() or not can_skip_param then
        return
    end

    maybe_arm_delay()
    local should_skip = skip_delay_until > 0.0 and os.clock() >= skip_delay_until
    local ok, error_message = pcall(function()
        can_skip_param:set(should_skip)
    end)

    if not ok then
        log("SKIP write failed phase=" .. phase .. " :: " .. tostring(error_message))
        return
    end

    if not should_skip and not delay_logged then
        delay_logged = true
        log("SKIP delaying action=" .. tostring(active_action))
    elseif should_skip and not force_logged then
        force_logged = true
        log("SKIP enabled action=" .. tostring(active_action) .. " phase=" .. phase)
    end
end

local function set_number(object, field_name, value)
    local ok, error_message = pcall(function()
        object[field_name] = value
    end)

    if not ok then
        log("write failed " .. field_name .. " :: " .. tostring(error_message))
        return false
    end

    return true
end

local function set_bool(object, field_name, value)
    local ok, error_message = pcall(function()
        object[field_name] = value
    end)

    if not ok then
        log("write failed " .. field_name .. " :: " .. tostring(error_message))
        return false
    end

    return true
end

local function read_field(object, field_name)
    local ok, value = pcall(function()
        return object[field_name]
    end)

    if ok then
        return value
    end

    return nil
end

local function array_len(value)
    if value == nil then
        return -1
    end

    local n = nil
    pcall(function()
        n = value:GetArrayNum()
    end)
    if type(n) == "number" then
        return n
    end

    pcall(function()
        n = #value
    end)
    if type(n) == "number" then
        return n
    end

    return -1
end

local function first_array_elem(value)
    if value == nil then
        return nil
    end

    local elem = nil
    pcall(function()
        elem = value:Get(1)
    end)
    if elem then
        return unwrap(elem)
    end

    pcall(function()
        elem = value[1]
    end)
    if elem then
        return unwrap(elem)
    end

    pcall(function()
        elem = value:Get(0)
    end)
    if elem then
        return unwrap(elem)
    end

    pcall(function()
        elem = value[0]
    end)
    if elem then
        return unwrap(elem)
    end

    return nil
end

local function object_outer(value)
    local object = unwrap(value)
    if not object then
        return nil
    end

    local ok, outer = pcall(function()
        return object:GetOuter()
    end)

    if ok then
        return outer
    end

    return nil
end

local function maybe_broadcast(object, field_name)
    local ok, error_message = pcall(function()
        local delegate = object[field_name]
        if delegate ~= nil then
            if type(delegate) == "function" then
                delegate()
            elseif delegate.Broadcast then
                delegate:Broadcast()
            end
        end
    end)

    if not ok then
        log("broadcast failed " .. field_name .. " :: " .. tostring(error_message))
        return false
    end

    return true
end

local function coordinator_of(state)
    local coord = unwrap(read_field(state, "TurnCoordinator"))
    if is_valid_object(coord) then
        return coord
    end
    if is_valid_object(last_seq) then
        coord = unwrap(read_field(last_seq, "TurnCoordinator"))
        if is_valid_object(coord) then
            return coord
        end
    end
    return nil
end

local function status_count(value)
    if value == nil then
        return nil
    end
    if type(value) == "boolean" or type(value) == "number" then
        return value
    end
    local n = array_len(value)
    if n >= 0 then
        return n
    end
    if type(value) == "table" then
        local inner = value[1] or value[0]
        if inner ~= nil and inner ~= value then
            return status_count(inner)
        end
    end
    local unwrapped = unwrap(value)
    if unwrapped ~= nil and unwrapped ~= value then
        return status_count(unwrapped)
    end
    return nil
end

local function call_presentation_status(state)
    local result = { ok = false }
    if not is_valid_object(state) then
        return result
    end

    local function accept(all_finished, finished, long_running, unfinished)
        result.ok = true
        result.all_finished = status_count(all_finished)
        result.finished = status_count(finished)
        result.long_running = status_count(long_running)
        result.unfinished = status_count(unfinished)
    end

    local ok, a, b, c, d = pcall(function()
        local all_finished, finished, long_running, unfinished = {}, {}, {}, {}
        state:GetAbilitiesForTurnPresentationStatus(
            all_finished, finished, long_running, unfinished)
        return all_finished, finished, long_running, unfinished
    end)
    if ok then
        accept(a, b, c, d)
        return result
    end

    ok, a, b, c, d = pcall(function()
        return state:GetAbilitiesForTurnPresentationStatus()
    end)
    if ok then
        accept(a, b, c, d)
        return result
    end

    local coord = coordinator_of(state)
    if is_valid_object(coord) then
        ok, a, b, c, d = pcall(function()
            local all_finished, finished, long_running, unfinished = {}, {}, {}, {}
            coord:GetAbilitiesForTurnPresentationStatus(
                all_finished, finished, long_running, unfinished)
            return all_finished, finished, long_running, unfinished
        end)
        if ok then
            accept(a, b, c, d)
            return result
        end
    end

    if not status_probe_logged then
        status_probe_logged = true
        log("SIM status-api unavailable :: " .. tostring(a))
    end
    return result
end

-- unstarted = still-unrequested presentations on the ledger. ready = every
-- remaining item is already playing (LongRunning) or this is an empty pad.
local function presentation_gate(state)
    local objects = array_len(read_field(state, "AbilityObjects"))
    local smrs = array_len(read_field(state, "AbilitySMRs"))

    if pending_unpresented_counter then
        return "unstarted", objects, smrs, "pending-counter"
    end

    if objects >= 0 and objects ~= last_objects_n then
        last_objects_n = objects
        last_objects_change_at = os.clock()
    end

    if objects > 0 and last_objects_change_at > 0.0
        and (os.clock() - last_objects_change_at) < 0.35 then
        return "unstarted", objects, smrs, "objects-growing"
    end

    if objects > 0 and smrs >= 0 and smrs < objects then
        return "unstarted", objects, smrs, "smrs-behind"
    end

    local st = call_presentation_status(state)
    if st.ok then
        if st.all_finished == true or st.all_finished == 1 then
            return "ready", objects, smrs, "status-all-finished"
        end
        local unfinished = tonumber(st.unfinished)
        local long_running = tonumber(st.long_running) or 0
        if unfinished ~= nil and unfinished > 0 then
            local not_started = unfinished - long_running
            if not_started > 0 then
                return "unstarted", objects, smrs,
                    "status-unstarted=" .. tostring(not_started)
            end
        end
    end

    return "ready", objects, smrs, "ledger"
end

-- Allow the coordinator to BeginPresentation the next target. Do not
-- SequenceDone cine or StopPresentation: those end the playing montage.
local function release_engine_ready(state)
    local coord = coordinator_of(state)
    if not is_valid_object(coord) then
        log("SIM engine-ready skipped no-coord")
        return
    end

    local ready_before = read_field(coord, "IsReadyForPresentation")
    set_bool(coord, "IsReadyForPresentation", true)
    maybe_broadcast(coord, "FinishedAllFires")
    log("SIM engine-ready before=" .. tostring(ready_before)
        .. " after=" .. tostring(read_field(coord, "IsReadyForPresentation"))
        .. " coord=" .. object_label(coord))
end

local function current_sim_timeout()
    -- Never shorten this for player counters. A 0.15s timeout ends the enemy
    -- turn before retaliation choreo starts, so stacks drop with no shot.
    return config.simultaneous_timeout
end

local function apply_watch_times(context)
    if not pack_on() then
        return
    end

    local delay = nil
    if in_assist_window() then
        delay = config.assist_delay
    elseif in_counter_window() then
        delay = config.counter_watch_delay
    elseif config.enemy_enabled then
        mark_enemy_turn()
        delay = config.watch_unit_delay
    end

    if delay == nil then
        return
    end

    local state = unwrap(context)
    if not state then
        return
    end

    set_number(state, "WatchUnitTimeMin", delay)
    set_number(state, "WatchUnitTimeMax", delay)
    set_number(state, "WatchUnitTime", delay)
    set_number(state, "WatchedUnitTime", delay)
    log("WATCH applied delay=" .. tostring(delay) .. " state=" .. object_label(state))
end

local function sim_ready_at()
    local origin = math.max(sim_started_at, last_presentation_at)
    local ready = origin + config.simultaneous_timeout

    if pending_unpresented_counter then
        -- Stay on this live node until the counter presents here.
        -- UnblockDelay used to TimedOut in 0.2s for a spare pad; that
        -- cut AoE hit-reacts and later retaliations off the ledger.
        local bus = config.counter_bus_hold
        if bus < config.simultaneous_timeout then
            bus = config.simultaneous_timeout
        end
        ready = last_counter_at + bus
        if ready > counter_window_until then
            ready = counter_window_until
        end
    elseif last_presentation_was_counter then
        -- Keep this node live so a follow-up counter (~1.8s later) can
        -- still activate with unblocked=false. Same wall-clock as the old
        -- 1s hold + 1s empty interstitial, but without spawning a spare SMR.
        ready = origin + config.simultaneous_timeout + config.counter_chain
    elseif in_counter_window() then
        -- Another squadmate may still fire 3s+ after the last presentation.
        -- Holding this empty node beats spawning 1s pad nodes, then dying
        -- before that shot activates (unblocked=true → 20–60s director wait).
        local bus = config.counter_bus_hold
        if bus < config.simultaneous_timeout then
            bus = config.simultaneous_timeout
        end
        ready = sim_started_at + bus
        if ready > counter_window_until then
            ready = counter_window_until
        end
    else
        ready = ready + config.counter_grace
    end

    return ready
end

refresh_sim_timeout = function()
    -- Timeout is no longer written as a cut. The 1s beat is a Lua poll.
    if sim_unblocked or not is_valid_object(last_sim_state) then
        return
    end
end

local function clear_counter_poison(reason)
    if pending_unpresented_counter then
        log("COUNTER poison-clear reason=" .. tostring(reason))
    end
    pending_unpresented_counter = false
    last_presentation_was_counter = false
    last_counter_at = 0.0
    pending_counter_ability = nil
    presentation_request_tried = false
    sim_token = sim_token + 1
end

local function maybe_reset_sim_wave()
    if last_sim_begin_at > 0.0 then
        local gap = os.clock() - last_sim_begin_at
        if gap >= WAVE_RESET_GAP then
            log("SIM wave-reset gap=" .. string.format("%.2f", gap))
            pending_unpresented_counter = false
            last_presentation_was_counter = false
            last_counter_at = 0.0
            pending_counter_ability = nil
            presentation_request_tried = false
            sim_token = sim_token + 1
        end
    end
    last_sim_begin_at = os.clock()
end

try_advance_sim = function()
    if not pack_on() or sim_unblocked or not config.enemy_enabled then
        return
    end

    if sim_started_at <= 0.0 then
        return
    end

    if os.clock() < sim_ready_at() then
        return
    end

    if not is_valid_object(last_sim_state) then
        return
    end

    local gate, objects, smrs, why = presentation_gate(last_sim_state)
    if gate == "unstarted" then
        if why == "pending-counter" and try_request_counter_presentation then
            try_request_counter_presentation()
        end
        if os.clock() - last_wait_unstarted_log >= 1.0 then
            last_wait_unstarted_log = os.clock()
            log("SIM wait-unstarted reason=" .. tostring(why)
                .. " objects=" .. tostring(objects)
                .. " smrs=" .. tostring(smrs)
                .. " state=" .. object_label(last_sim_state))
        end
        if schedule_sim_advance
            and (os.clock() - last_unstarted_schedule_at) >= 0.30 then
            last_unstarted_schedule_at = os.clock()
            schedule_sim_advance(0.35)
        end
        return
    end

    sim_unblocked = true
    -- TimedOut leaves this story runner so the next target can start.
    -- Engine ready is the same beat so the coordinator is not still waiting
    -- cine SequenceDone. Montages keep playing via Unrestrict.
    -- Do not force IsPresentationFinished (that compressed montages).
    set_bool(last_sim_state, "bWaitingOnAbilityObjects", false)
    release_engine_ready(last_sim_state)
    maybe_broadcast(last_sim_state, "AllAbilitiesFinished")
    maybe_broadcast(last_sim_state, "TimedOut")
    log("SIM advance timed-out-only state=" .. object_label(last_sim_state)
        .. " objects=" .. tostring(objects)
        .. " smrs=" .. tostring(smrs)
        .. " why=" .. tostring(why))
end

-- OnStateUpdate often does not tick while a node waits on presentation,
-- so TimedOut must also be scheduled from OnStateBegin / counter events.
-- Do not LoopAsync+StopPresentation (that crashed in CommitAbility).
schedule_sim_advance = function(delay_override)
    sim_token = sim_token + 1
    local token = sim_token
    local delay = delay_override
    if delay == nil then
        delay = sim_ready_at() - os.clock()
    end
    if delay < 0.05 then
        delay = 0.05
    end
    if delay > 5 then
        delay = 5
    end

    pcall(function()
        ExecuteWithDelay(math.floor(delay * 1000 + 0.5), function()
            if token ~= sim_token then
                return
            end
            pcall(function()
                ExecuteInGameThread(function()
                    if token ~= sim_token then
                        return
                    end
                    try_advance_sim()
                end)
            end)
        end)
    end)
end

-- A counter that activates after the last EnemyTurnBase runner has already
-- ended is counted as unfinished but never presented. The native call takes
-- two parameters; the second is an Out runner. Passing a UObject there
-- failed with "Tried storing reference to a Lua table for an 'Out'
-- parameter". Pass an empty table (UE4SS Out-arg convention).
try_request_counter_presentation = function()
    if not pending_unpresented_counter or presentation_request_tried then
        return
    end

    if not is_valid_object(last_seq) then
        log("COUNTER request skipped no-seq")
        return
    end

    if not is_valid_object(pending_counter_ability) then
        log("COUNTER request skipped no-ability")
        return
    end

    presentation_request_tried = true

    local ability = unwrap(pending_counter_ability)
    local function first_line(err)
        return (tostring(err or ""):match("^[^\r\n]+")) or tostring(err)
    end

    local attempts = {
        {
            "out-table",
            function()
                local out_runner = {}
                last_seq:TurnDirectorRequestAbilityPresentation(ability, out_runner)
                return out_runner
            end,
        },
        {
            "out-table-prefill",
            function()
                local out_runner = { unwrap(last_runner) }
                last_seq:TurnDirectorRequestAbilityPresentation(ability, out_runner)
                return out_runner
            end,
        },
    }

    for _, attempt in ipairs(attempts) do
        log("COUNTER request-presentation ability=" .. object_label(ability)
            .. " via=" .. attempt[1])
        local ok, result = pcall(attempt[2])
        if ok then
            local filled = nil
            if type(result) == "table" then
                filled = result[1] or result[0]
            end
            log("COUNTER request ok via=" .. attempt[1]
                .. " out=" .. object_label(filled))
            return
        end
        log("COUNTER request failed via=" .. attempt[1]
            .. " :: " .. first_line(result))
    end
end

local function apply_simultaneous_timeout(context)
    if not pack_on() or not config.enemy_enabled then
        return
    end

    local state = unwrap(context)
    if not state then
        return
    end

    maybe_reset_sim_wave()

    -- Presentation often logs on the same frame as this node's OnStateBegin.
    -- Do not clobber last_presentation_was_counter in that case.
    local keep_counter = last_presentation_was_counter
        and (os.clock() - last_presentation_at) < 0.08

    mark_enemy_turn()
    sim_token = sim_token + 1
    last_sim_state = state
    sim_started_at = os.clock()
    sim_unblocked = false
    if not keep_counter then
        last_presentation_at = sim_started_at
        last_presentation_was_counter = false
    end

    local hold = sim_ready_at() - sim_started_at
    if hold < 0.15 then
        hold = 0.15
    end
    if hold > 5 then
        hold = 5
    end

    last_objects_n = array_len(read_field(state, "AbilityObjects"))
    last_objects_change_at = os.clock()
    last_wait_unstarted_log = 0.0
    last_unstarted_schedule_at = 0.0

    -- 1s is a Lua checkpoint, not a native Timeout cut. Writing Timeout
    -- here made the SM TimedOut even when the ledger still had unstarted
    -- hit-reacts / rocket-arm-next / retaliations.
    log("SIM hold=" .. tostring(hold)
        .. " pending=" .. tostring(pending_unpresented_counter)
        .. " counter_pres=" .. tostring(last_presentation_was_counter)
        .. " smrs=" .. tostring(array_len(read_field(state, "AbilitySMRs")))
        .. " objects=" .. tostring(array_len(read_field(state, "AbilityObjects")))
        .. " state=" .. object_label(state))
    schedule_sim_advance()
end

-- Backup if OnStateUpdate actually ticks. Primary advance is ExecuteWithDelay.
local function maybe_advance_sim(context)
    local state = unwrap(context)
    if state then
        last_sim_state = state
    end
    try_advance_sim()
end

local function apply_wait_story_timeout(context)
    if not pack_on() then
        return
    end

    if not config.enemy_enabled and not in_counter_window() then
        return
    end

    local state = unwrap(context)
    if not state then
        return
    end

    if config.enemy_enabled then
        mark_enemy_turn()
    end

    wait_story_started_at = os.clock()
    last_wait_story_state = state
    log("STORY native-wait state=" .. object_label(state))
end

local function maybe_finish_wait_story(_context)
    -- Leave WaitForStory native. TimeoutOccured here locked grenade/AoE HUD.
end

local function force_is_finished(_result)
    -- Do not force IsPresentationFinished. That ends the remaining montage
    -- instead of letting it overlap at normal speed.
end

local function apply_fast_presentation(seq, skip_cine, keep_playing)
    if skip_cine then
        set_bool(seq, "bAllowCineBeatsDuringAITurn", false)
        set_bool(seq, "bAllowCineBeatsOverride", false)
    end

    if keep_playing then
        set_bool(seq, "bUnrestrictPlayingAnimations", true)
        set_bool(seq, "bAllowCinematicStateMachine", true)
    end
end

local function on_presentation_request(context, ...)
    if not pack_on() then
        return
    end

    local ability = select(1, ...)
    local runner = select(2, ...)
    local ability_label = object_label(ability)

    if active_action_valid() and ability_label == active_ability_label then
        active_presentation_requested = true
        active_runner_hint = runner_hint(runner)
        maybe_arm_delay()
    end

    local seq = unwrap(context)
    if not seq then
        return
    end

    last_seq = seq
    local runner_obj = unwrap(runner)
    if is_valid_object(runner_obj) then
        last_runner = runner_obj
    end

    if config.counter_enabled and is_counter_ability(ability_label) then
        pending_unpresented_counter = false
        pending_counter_ability = nil
        presentation_request_tried = false
        last_presentation_at = os.clock()
        last_presentation_was_counter = true
        counter_window_until = os.clock() + COUNTER_WINDOW_SECONDS
        apply_fast_presentation(seq, config.counter_skip_cine, config.counter_keep_playing)
        log("COUNTER presentation ability=" .. ability_label
            .. " runner=" .. object_label(runner_obj))
        if refresh_sim_timeout then
            refresh_sim_timeout()
        end
        if schedule_sim_advance then
            schedule_sim_advance()
        end
        return
    end

    local player_turn = read_field(seq, "IsPlayerTurn")
    if player_turn == true then
        clear_counter_poison("player-presentation")
        return
    end

    if not config.enemy_enabled then
        return
    end

    mark_enemy_turn()
    last_presentation_at = os.clock()
    last_presentation_was_counter = false
    apply_fast_presentation(seq, config.skip_cine_beats, config.keep_playing)
end

local function on_ability_committed(context, ...)
    if not pack_on() then
        return
    end

    local ability = select(1, ...)
    local label = object_label(ability)
    if config.counter_enabled and is_counter_ability(label) then
        arm_counter_window(label, unwrap(ability) or ability)
    end

    if config.enemy_enabled then
        mark_enemy_turn()
    end
end

local function suppress_cine_beat(_, should_play)
    if not pack_on() or not should_play then
        return
    end

    local skip = (config.enemy_enabled and config.skip_cine_beats and in_enemy_turn())
        or (in_counter_window() and config.counter_skip_cine)

    if not skip then
        return
    end

    pcall(function()
        should_play:set(false)
    end)
end

local function on_player_turn_query(_, is_turn)
    if not is_turn then
        return
    end

    local ok, value = pcall(function()
        return is_turn:get()
    end)

    if ok and value == true then
        clear_counter_poison("player-turn")
    elseif ok and value == false and config.enemy_enabled then
        mark_enemy_turn()
    end
end

local function on_choreo_begin(context)
    if not pack_on() then
        return
    end

    if active_action_valid() and active_presentation_requested then
        local context_label = object_label(context)
        if active_runner_hint and string.find(context_label, active_runner_hint, 1, true) then
            active_presentation_state_started = true
            maybe_arm_delay()
        end
    end

    local keep = (config.enemy_enabled and config.keep_playing and in_enemy_turn())
        or (in_counter_window() and config.counter_keep_playing)

    if not keep then
        return
    end

    -- Montage overlap comes from bUnrestrictPlayingAnimations on the sequence
    -- manager. Do not set bStopSequenceOnStateEnd=false: that orphans cinematic
    -- SMRs so SequenceDone never fires. After ~12 EnemyTurnBase runners the
    -- coordinator will not spawn the next beat (4s hitch at counter 3, then
    -- deadlock when the next retaliation activates with no runner).
end

local function on_view_target_begin(context)
    on_choreo_begin(context)
    if not pack_on() then
        return
    end

    if not in_enemy_turn() and not in_counter_window() and not in_assist_window() then
        return
    end

    local state = unwrap(context)
    if not state then
        return
    end

    -- Camera tag wait must not eat the 0.5s action budget.
    set_number(state, "MaximumDelayTime", 0.05)
    set_number(state, "Minimum Time Delay", 0.0)
end

local function register_hook(path, label, on_pre, on_post)
    if registered_hooks[path] then
        return true
    end

    local ok, error_message = pcall(function()
        RegisterHook(path, function(context, ...)
            if on_pre then
                local callback_ok, callback_error = pcall(on_pre, context, ...)
                if not callback_ok then
                    log("callback PRE failed " .. label .. " :: " .. tostring(callback_error))
                end
            end
        end, function(context, ...)
            if on_post then
                local callback_ok, callback_error = pcall(on_post, context, ...)
                if not callback_ok then
                    log("callback POST failed " .. label .. " :: " .. tostring(callback_error))
                end
            end
        end)
    end)

    if not ok then
        if not hook_fail_logged[path] then
            hook_fail_logged[path] = true
            log("HOOK unavailable " .. label .. " :: " .. tostring(error_message))
        end
        return false
    end

    registered_hooks[path] = true
    log("HOOK ok " .. label)
    return true
end

local function register_activate_hooks(paths, window_fn, kind)
    for _, path in ipairs(paths) do
        if type(path) == "string" then
            local short = path:match("([^/]+)_C:")
            register_hook(path, kind .. " " .. tostring(short), function(context, ...)
                window_fn(context, ...)
            end, nil)
        end
    end
end

local function register_hooks()
    register_hook(TARGETING_COMPLETED_PATH, "TargetingCompleted", arm_action, nil)
    register_hook(CAN_SKIP_PATH, "CanSkipAbilityPresentation", function(_, can_skip)
        apply_can_skip(can_skip, "pre")
    end, function(_, can_skip)
        apply_can_skip(can_skip, "post")
    end)
    register_hook(COMMIT_END_PATH, "CommitAndPresentPlan.OnStateEnd", function()
        clear_active_action()
    end, nil)
    register_hook(PRESENTATION_REQUEST_PATH, "TurnDirectorRequestAbilityPresentation", on_presentation_request, nil)
    register_hook(CHOREOGRAPHED_ROOT .. "OnStateBegin", "PlayChoreographedSequence.OnStateBegin", on_choreo_begin, nil)
    register_hook(VIEW_TARGET_DELAY_ROOT .. "OnStateBegin", "DelayUntilViewTargetTagsMatch.OnStateBegin", on_view_target_begin, nil)
    register_hook(RUN_BY_PLAN_BEGIN, "RunAbilitiesByPlanIndex.OnStateBegin", apply_watch_times, nil)
    register_hook(SIMULTANEOUS_BEGIN, "StartAbilitiesSimultaneously.OnStateBegin", apply_simultaneous_timeout, nil)
    register_hook(SIMULTANEOUS_UPDATE, "StartAbilitiesSimultaneously.OnStateUpdate", maybe_advance_sim, nil)
    register_hook(WAIT_STORY_BEGIN, "WaitForStoryAbilitiesToFinish.OnStateBegin", apply_wait_story_timeout, nil)
    register_hook(WAIT_STORY_UPDATE, "WaitForStoryAbilitiesToFinish.OnStateUpdate", maybe_finish_wait_story, nil)
    register_hook(WAIT_STORY_IS_FINISHED, "WaitForStoryAbilitiesToFinish.IsPresentationFinished", function(_, result)
        force_is_finished(result)
    end, function(_, result)
        force_is_finished(result)
    end)
    register_hook(ABILITY_COMMITTED, "OnAbilityCommitted", on_ability_committed, nil)
    register_hook(SHOULD_PLAY_CINE, "ShouldPlayExecutionCineBeat", function(context, should_play)
        suppress_cine_beat(context, should_play)
    end, function(context, should_play)
        suppress_cine_beat(context, should_play)
    end)
    register_hook(IS_PLAYER_TURN, "IsPlayerTurn", nil, on_player_turn_query)
    register_activate_hooks(ASSIST_ACTIVATE_PATHS, arm_assist_window, "assist")
    register_activate_hooks(COUNTER_ACTIVATE_PATHS, function(context)
        arm_counter_window("activate-hook", unwrap(context))
    end, "counter")
end

local function schedule_hook_retries()
    -- First map pass often fails (assets not loaded). Retry until Overwatch
    -- gun classes and IsPlayerTurn are present.
    local delays_ms = { 1000, 4000, 8000, 12000, 20000 }
    for _, ms in ipairs(delays_ms) do
        pcall(function()
            ExecuteWithDelay(ms, function()
                ExecuteInGameThread(register_hooks)
            end)
        end)
    end
end

load_config()
log("LOAD version=" .. MOD_VERSION
    .. " build=" .. BUILD_ID
    .. " enabled=" .. tostring(config.enabled)
    .. " actions=" .. tostring(config.actions_enabled)
    .. " enemy=" .. tostring(config.enemy_enabled)
    .. " assist=" .. tostring(config.assist_enabled)
    .. " counter=" .. tostring(config.counter_enabled)
    .. " chain=" .. tostring(config.counter_chain)
    .. " bus=" .. tostring(config.counter_bus_hold)
    .. " deadlock-fix=status-sync")

local ok, error_message = pcall(function()
    RegisterLoadMapPostHook(function()
        ExecuteInGameThread(register_hooks)
        schedule_hook_retries()
    end)
end)

if not ok then
    log("LOAD map hook failed :: " .. tostring(error_message))
end
