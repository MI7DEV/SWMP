# Swift Combat and Retaliation

**Star Wars: Zero Company** UE4SS mod · Version **2.2.0**

One Lua pack that shortens **player commits, assist cameras, enemy-turn attacks, and player retaliation / overwatch** to about **one second per beat**. The previous montage keeps playing at normal speed (overlap), instead of squashing a 2-second anim into 0.5 seconds.

Requires the game-specific **UE4SS** build (not bundled). Do **not** also enable the older `SwiftActions` / `SwiftAssistShots` / `SwiftEnemyTurn` folders — this pack replaces all three.

Nexus **Swift Enemy Turn 1.0.0** was the early enemy-turn-only build. Use this pack instead: folder name is `SwiftCombat`, and disable `SwiftEnemyTurn`.

## Features

- **Enemy turn ~1s beat** — the next AI attack can start without waiting for the full previous cinematic.
- **Normal-speed overlap** — cine muzzle / laser beats stay on by default; walks are not compressed into a drift. Movement is never skipped.
- **Ledger sync (2.2)** — 1s is a checkpoint. If the ledger still has **unstarted** presentations (multi-hit reacts, rocket arm-next, unrequested counters), the director does not `TimedOut`. Already-playing montages keep going while director and engine switch focus together.
- **Counters present on the live node** — no 0.2s UnblockDelay cut to spawn a spare pad.
- **WaitForStory stays native** — no early `TimeoutOccured` (that locked grenade / AoE HUD).
- **Faster assist cameras**.
- **Player CanSkip off by default**.
- **Tunable** — all timing is in `config.ini`.

Does not change damage, AI decisions, or saves. Presentation timing only.

## 2.2 fixes

Versus frozen 2.0, and versus Nexus Swift Enemy Turn 1.0.0 reports:

| Report | Cause | 2.2 |
|---|---|---|
| ~5–10s hitch after a presented single shot | Director `TimedOut` while the engine still waited on cine | Same-beat TurnCoordinator ready (`IsReadyForPresentation` / `FinishedAllFires`); montage is not stopped |
| Softlock after B2 rocket fire then arm-next | Director left before the next presentation was requested | No `TimedOut` while the ledger still has unstarted items |
| Shared Suffering / grenade AoE softlock | `WaitForStory` `TimeoutOccured` | WaitForStory left native |
| Multi-hit rocket then chained retaliations stall | First counter UnblockDelay-cut the node | Request presentation on the live node |
| SET 1.0 retaliation ~60/40 | No BusHold / Out-table request | Present on the live node (BusHold kept) |
| Per-skill AoE whitelist still deadlocked | Missed names still cut | No skill whitelist — only “playing vs not started” |

2.0 vs 1.0: fixes the multi-unit retaliation stall where the last shot activated after the story node had already timed out.

## Install

1. Install [UE4SS for Star Wars Zero Company](https://www.nexusmods.com/starwarszerocompany/mods).
2. Close the game.
3. Copy the **`SwiftCombat`** folder into:

   `SWZeroCompany\Binaries\Win64\ue4ss\Mods\`

4. Edit `ue4ss\Mods\mods.txt` and add this line **above** `Keybinds : 1`:

   `SwiftCombat : 1`

5. Set `SwiftActions` / `SwiftAssistShots` / `SwiftEnemyTurn` to `: 0` (or remove those lines) if those folders are still present.
6. Launch the game. `UE4SS.log` should show `Starting Lua mod 'SwiftCombat'` and `LOAD version=2.2 build=2.2-status-sync`.

## Uninstall

Delete `ue4ss\Mods\SwiftCombat` and remove its line from `mods.txt`.

## Config

Edit `SwiftCombat\config.ini`:

| Section | Key | Default | Effect |
|---|---|---|---|
| General | Enabled | true | Master switch |
| Actions | Enabled | false | Player presentation skip (causes walk drift; off by default) |
| Actions | SafetyDelay | 1.00 | Minimum time before a skip |
| EnemyTurn | SimultaneousTimeout | 1.00 | Lua checkpoint interval (not “animation finished”) |
| EnemyTurn | WatchUnitDelay | 1.00 | Watch-unit wait |
| EnemyTurn | SkipCineBeats | false | Skip AI cinematic camera beats |
| AssistShots | AssistDelay | 1.00 | Watch delay during assist window |
| PlayerCounter | CounterChain | 1.00 | Extra hold after a counter presentation |
| PlayerCounter | BusHold | 4.00 | How long an empty node may stay live while another unit may still retaliate |
| PlayerCounter | SkipCineBeats | false | Skip counter cine beats (hides muzzle flash) |

`WaitForStoryTimeout` / `UnblockDelay` remain in the ini; 2.2 does not use them to end a presentation early.

## Compatibility

- Game: *Star Wars: Zero Company*
- Requires the game-specific UE4SS compatibility build
- Replaces SwiftActions, SwiftAssistShots, and SwiftEnemyTurn — do not load those alongside this pack

## License

Fan mod for personal and community non-commercial use. Game assets remain © their respective owners.
