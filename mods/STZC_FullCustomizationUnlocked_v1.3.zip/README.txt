ZCUnlocked
==========


WHAT IT DOES
------------
* Turn a plain humanoid recruit into a Padawan -- Tel-Rea's class, spec, talent
  and lightsaber.
* Or into a Mandalorian -- Cly's class, the Warrior spec, the jetpack talent and
  a blaster loadout.
* Let a human wear the Man001, Man002 or Cly beskar sets in the wardrobe, color
  sliders and all: helms, chest, arms, legs, boots.
* Change specialization, talent and weapon back off any hero kit whenever you
  want -- the game normally locks those to their hero (even the lightsaber); this
  keeps them swappable like a normal recruit's.


WHAT YOU NEED FIRST
-------------------
* Star Wars: Zero Company on Steam, build 24874058.
* UE4SS for Zero Company:
  https://www.nexusmods.com/starwarszerocompany/mods/9


PUTTING IT IN
-------------
1. Quit the game.
2. Get UE4SS set up in  <game>\SWZeroCompany\Binaries\Win64  (follow its own steps).
3. Drop the contents of this zip into that same Win64 folder. You should land at:
      ...\ue4ss\Mods\ZCUnlocked\dlls\main.dll
4. Launch. It flips itself on -- that's what the enabled.txt is for, so leave it.





TAKING IT OUT
-------------
Quit, delete  ...\ue4ss\Mods\ZCUnlocked . If someone's actually wearing the modded
armor, put them back in stock gear and save before you remove it.
