ZC_Endless - endless / career mode for STAR WARS Zero Company

REQUIRES: "UE4SS for STAR WARS Zero Company" by Vercadi (Nexus mod #9).

INSTALL:
  Copy this ZC_Endless folder into
    ...\STAR WARS Zero Company\SWZeroCompany\Binaries\Win64\ue4ss\Mods\
  so you have ...\ue4ss\Mods\ZC_Endless\Scripts\main.lua
  (Optional: add "ZC_Endless : 1" to ue4ss\Mods\mods.txt above the Keybinds line.)

USE:
  Load a campaign. Press End in the Den to open the menu.
  Number keys 1-7 toggle rows. Key 7 saves your choices.

Campaign-never-ends is on by default and stable.
Automatic holotable top-up is EXPERIMENTAL and off by default - see the mod page.

Full docs + source: https://github.com/venatrix-ritz/ZC-Endless
Credits: see CREDITS.md - this builds on the whole SWZC modding community.
