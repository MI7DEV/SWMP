-- 	author: Caites

--  console commands:
--      ironman_off       disables Beskar mode for the loaded save
--      ironman_on        re-enables it
--      permadeath_off    disables permadeath
--      permadeath_on     re-enables it
--
--  skiptutorial:
--      true  - skips tutorial mission (character class can be changes on cycle 3)
--      false - leaves tutorials and the opening mission untouched
--=====================================================================

return {
    SkipTutorial = true,
}
