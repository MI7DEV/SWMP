local MOD_NAME = "NoBeskarMode"

local cfg = {
    SkipTutorial = true,
}

do
    local ok, loaded = pcall(require, "config")
    if ok and type(loaded) == "table" then
        for k, v in pairs(loaded) do cfg[k] = v end
    end
end

local FAST_MS = 1000
local IDLE_MS = 15000

local function log(fmt, ...)
    local msg = fmt
    if select("#", ...) > 0 then
        local ok, formatted = pcall(string.format, fmt, ...)
        if ok then msg = formatted end
    end
    print(string.format("[%s] %s\n", MOD_NAME, msg))
end

local function valid(obj)
    return obj ~= nil and obj:IsValid()
end

local function str(v)
    if v == nil then return "" end
    if type(v) == "string" then return v end
    local ok, s = pcall(function() return v:ToString() end)
    if ok and s then return s end
    return tostring(v)
end

local function get(obj, name)
    if not valid(obj) then return nil end
    local ok, v = pcall(function() return obj[name] end)
    if ok then return v end
    return nil
end

local function set(obj, name, value)
    if not valid(obj) then return false end
    local ok = pcall(function() obj[name] = value end)
    if not ok then return false end
    return get(obj, name) == value
end

local cache = {}

local function cached(className)
    local e = cache[className]
    if e and valid(e.obj) then return e.obj end

    if not e then
        e = { obj = nil, misses = 0, skip = 0 }
        cache[className] = e
    end
    e.obj = nil

    if e.skip > 0 then
        e.skip = e.skip - 1
        return nil
    end

    local ok, found = pcall(FindFirstOf, className)
    if ok and valid(found) then
        e.obj = found
        e.misses = 0
        e.skip = 0
        return found
    end

    e.misses = e.misses + 1
    e.skip = math.min(32, 2 ^ math.min(e.misses, 5))
    return nil
end

local function GetGameInstance()
    return cached("BrunoGameInstance") or cached("BitReactorGameGameInstance")
end

local function GetGameStatics()
    local e = cache.__statics
    if e and valid(e) then return e end
    local s = StaticFindObject("/Script/BitReactorGame.Default__BitReactorGameStatics")
    if valid(s) then cache.__statics = s return s end
    return nil
end

local function ReadIronman()
    local gi, statics = GetGameInstance(), GetGameStatics()
    if not gi or not statics then return nil end
    local ok, v = pcall(function() return statics:GetIronmanMode(gi) end)
    if ok then return v end
    local sd = get(gi, "StrategyData")
    if sd ~= nil then return get(sd, "bIronman") end
    return nil
end

local function ClearSaveBlocker()
    local gi, ss = GetGameInstance(), cached("BrunoSaveGameSubsystem")
    if not gi or not ss then return end
    local blocked = false
    pcall(function() blocked = ss:AreSaveGamesBlocked() end)
    if not blocked then return end
    local reason = ""
    pcall(function() reason = str(ss:GetSaveGameBlockerReason()) end)
    pcall(function() ss:RemoveUnconditionalSaveBlocker(gi) end)
    log("Cleared save blocker%s", reason ~= "" and (" ('" .. reason .. "')") or "")
end

local function SetIronman(bEnabled)
    local gi = GetGameInstance()
    if not gi then log("No campaign loaded.") return end
    local statics = GetGameStatics()
    if not statics then log("Could not resolve BitReactorGameStatics CDO.") return end

    local before = ReadIronman()
    pcall(function() statics:SetIronmanMode(gi, bEnabled) end)
    if ReadIronman() ~= bEnabled then
        pcall(function() gi.StrategyData.bIronman = bEnabled end)
    end

    local after = ReadIronman()
    log("Ironman: %s -> %s", tostring(before), tostring(after))

    if after == false then
        ClearSaveBlocker()
        log("Save from the in-game menu to make it permanent.")
    end
end

local function SetPermaDeath(bEnabled)
    local gi = GetGameInstance()
    if not gi then log("No campaign loaded.") return end
    local statics = GetGameStatics()
    if not statics then log("Could not resolve BitReactorGameStatics CDO.") return end

    local before
    pcall(function() before = statics:GetPermaDeathWC(gi) end)
    pcall(function() statics:SetPermaDeath(gi, bEnabled) end)

    local after
    pcall(function() after = statics:GetPermaDeathWC(gi) end)
    if after ~= bEnabled then
        pcall(function() gi.StrategyData.bPermaDeath = bEnabled end)
        pcall(function() after = statics:GetPermaDeathWC(gi) end)
    end

    log("PermaDeath: %s -> %s", tostring(before), tostring(after))
end

local ftueCleared = false
local creationHookFired = false

local function GuidIsSet(g)
    if g == nil then return false end
    local ok, res = pcall(function()
        return (g.A ~= 0) or (g.B ~= 0) or (g.C ~= 0) or (g.D ~= 0)
    end)
    return ok and res or false
end

local function ClearFTUE()
    local gi = GetGameInstance()
    if not gi then return false end
    if get(gi, "bFirstTimeUserExperience") == false then
        ftueCleared = true
        return true
    end
    local ok = pcall(function() gi:SetFirstTimeUserExperience(false) end)
    if not ok or get(gi, "bFirstTimeUserExperience") ~= false then
        set(gi, "bFirstTimeUserExperience", false)
    end
    ftueCleared = (get(gi, "bFirstTimeUserExperience") == false)
    return ftueCleared
end

local function CharacterCreationDone()
    if creationHookFired then return true end
    local gi = GetGameInstance()
    if not gi then return false end
    return GuidIsSet(get(gi, "PlayerCharacterID"))
end

local function EnforceTutorialSubsystem()
    local tm = cached("BitReactorTutorialManagerSubsystem")
    if not tm then return false end

    local clean = true
    if get(tm, "bEnableTutorialSystem") ~= false then
        set(tm, "bEnableTutorialSystem", false)
        clean = false
    end
    if get(tm, "bAllowNewTutorials") ~= false then
        set(tm, "bAllowNewTutorials", false)
        pcall(function() tm:PauseNewTutorials() end)
        clean = false
    end
    return clean
end

local function EnforceUserFlags()
    local clean = true

    local s = cached("BitReactorUserSettingsLocal")
    if s then
        if get(s, "bPlayTutorialMission") ~= false then
            pcall(function() s:SetPlayTutorialMission(false) end)
            clean = false
        end
        if get(s, "bShowTutorials") ~= false then
            pcall(function() s:SetShowTutorials(false) end)
            clean = false
        end
    else
        clean = false
    end

    local p = cached("BitReactorCoreUserProfile")
    if p then
        if get(p, "bTutorialMission") ~= false then
            set(p, "bTutorialMission", false)
            clean = false
        end
        if get(p, "bTutorialPopups") ~= false then
            set(p, "bTutorialPopups", false)
            clean = false
        end
    else
        clean = false
    end

    return clean
end

local function EnforceGameInstanceFlags()
    local gi = GetGameInstance()
    if not gi then return false end
    local clean = true

    if not ftueCleared then
        if CharacterCreationDone() then
            ClearFTUE()
        end
        clean = false
    end

    local sd = get(gi, "StrategyData")
    if sd ~= nil and get(sd, "bEnableTutorials") ~= false then
        pcall(function() gi.StrategyData.bEnableTutorials = false end)
        clean = false
    end

    return clean
end

local function EnforceAll()
    local a = EnforceTutorialSubsystem()
    local b = EnforceUserFlags()
    local c = EnforceGameInstanceFlags()
    return a and b and c
end

local function RegisterCommand(name, fn)
    local handler = function(_, _, _)
        ExecuteInGameThread(fn)
        return true
    end
    local ok = pcall(RegisterConsoleCommandGlobalHandler, name, handler)
    if not ok then
        pcall(RegisterConsoleCommandHandler, name, handler)
    end
end

RegisterCommand("ironman_off",    function() SetIronman(false) end)
RegisterCommand("ironman_on",     function() SetIronman(true) end)
RegisterCommand("permadeath_off", function() SetPermaDeath(false) end)
RegisterCommand("permadeath_on",  function() SetPermaDeath(true) end)

local cleanStreak = 0
local currentInterval = FAST_MS

local function Tick()
    ExecuteInGameThread(function()
        local ok, clean = pcall(EnforceAll)
        if not ok then return end

        if clean then
            cleanStreak = cleanStreak + 1
            if cleanStreak >= 3 then
                currentInterval = IDLE_MS
            end
        else
            cleanStreak = 0
            currentInterval = FAST_MS
        end
    end)

    pcall(function() ExecuteWithDelay(currentInterval, Tick) end)
end

if cfg.SkipTutorial then
    local paths = {
        "/Script/Bruno.BrunoDatabankNewCharacterViewModel:ConfirmNewDatabankCharacter",
        "/Script/Bruno.BrunoDatabankNewCharacterViewModel:ConfirmNewCharacter",
    }
    for _, path in ipairs(paths) do
        local ok = pcall(function()
            RegisterHook(path, function()
                creationHookFired = true
            end)
        end)
        if ok then break end
    end

    pcall(function() ExecuteWithDelay(2000, Tick) end)
end

log("loaded. Commands: ironman_off | ironman_on | permadeath_off | permadeath_on")
