GameWatcher - God Tier - Star Wars Zero Company
===============================================

Multiplies your squad's health and ALL of their weapon damage by 5.

Everything is scaled, not set to a flat number, so the balance between
characters and between weapons survives. Anakin still out-fights a trooper,
the scattergun still outdamages a pistol. You are simply five times stronger
than the enemy expects.


INSTALL
-------
Copy the three files (.pak, .ucas, .utoc) into:

    Star Wars Zero Company\SWZeroCompany\Content\Paks\~mods\

Create the "~mods" folder if it does not exist. The tilde is part of the name
and controls load order. Then start the game - no script extender needed.

To uninstall, delete the three files. No game file is modified, so Steam's
"Verify integrity of game files" is never required.


IMPORTANT - HEALTH NEEDS A NEW CHARACTER
----------------------------------------
Health is written into your save when a character is created, so the health
boost only applies to characters recruited AFTER installing this. An existing
squad keeps its old health.

Weapon damage is not saved that way and applies immediately, on any save.

  Existing save  ->  x5 damage only
  New game       ->  x5 damage and x5 health


HEALTH (x5)
-----------
Covers every squad member, not just story characters. "Squad trooper" is the
template all recruited and custom characters are built from.

    Squad trooper (all recruits)    28 -> 140
    Bennic                          52 -> 260
    Baker                           64 -> 320
    Rex                             72 -> 360
    Tel Rea (Padawan)               28 -> 140
    Anakin (Jedi)                  250 -> 1250


WEAPON DAMAGE (x5) - all 48 player weapons, every upgrade tier
--------------------------------------------------------------
Blasters      Pistol 6->30, Repeater 8->40, Rifle 10->50, Longarm 12->60,
              Rex's DC-17 17->85, DC-17m Longarm 20->100, DC-17m Repeater 12->60,
              Quickdraw Pistol 4->20
Tiered guns   Scattergun 18-36 -> 90-180, Flamethrower 6-12 -> 30-60,
              Heavy Blaster Pistol 10-16 -> 50-80, Ion Blaster 9-16 -> 45-80
Melee         Standard Lightsaber 10->50, Anakin's Lightsaber 28->140,
              Brutal Strike 10->50, Bull Rush 8->40, Kabb's Uppercut 8->40
Thrown        Thermal Detonator 12-30 -> 60-150, Droid Popper 12-24 -> 60-120,
              Concussion Grenade 2-8 -> 10-40, Firebomb 4-8 -> 20-40

Smoke Bombs are untouched - they deal no damage in the first place.

Enemy stats and weapons are untouched, as are rewards, AP and accuracy.


COMPATIBILITY
-------------
Conflicts with any other mod editing player weapon attributes or character
health.

Built against the game as of September 2026. A patch changing these values could
make this revert to vanilla - it will not break anything, it just stops working.


CREDITS
-------
Made by GameWatcher. https://www.gamewatcher.com
